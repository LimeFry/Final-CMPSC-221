import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.sql.*;
// for the border
import javax.swing.border.Border;

public class Final_Project extends JFrame implements ActionListener{
        static JMenuBar mb;
        static JFrame f;
        private static JPanel cardLayout;
        private static CardLayout cardLayout4use = new CardLayout();

        // for the user
        private static String user = null;
        private static int developer = 0;
        private static int add_edit = 0;
        private static String admin = null;

        // for database connection, commonalities
//        private static String mainDatabase = "MAIN_DATABASE";
//        private static String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
//        private static Statement stm;
//        private static Connection conn = null;
//        private static PreparedStatement psstm;

        // font
        private static Font labelFont = new Font("Times New Roman", Font.PLAIN, 18);
        // color
        private static Color customerColor = new Color(226, 135, 54);
        private static Color adminColor = new Color(78, 87, 123);
        private static Color devColor = new Color(146, 213,123);

        //--------CREATING ALL THE DATABASES----------------------------------------------------------------------------
        public static void createDatabase() {
                // common variables
                String mainDatabase = "MAIN_DATABASE";
                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                Statement stm;
                Connection conn = null;
                PreparedStatement psstm;
                ResultSet myResult1, myResult2, myResult3, myResult4;
                String createCust = "CREATE TABLE CUST (ID INT, NAME VARCHAR(30), TAGS VARCHAR(255))"; // MAYBE ADD STUFF FROM WHITEBORAD -> REMOVE BEFORE SUBMISSION
                String createDev = "CREATE TABLE DEV (DEVID INT, OWNEDGAMES VARCHAR(255))";
                String createBackend = "CREATE TABLE BACKEND (BACKENDNAME VARCHAR(30))";
                String createGame = "CREATE TABLE GAME (GAMENAME VARCHAR(30), GAMESCORE DOUBLE, GAMERATING VARCHAR(30), GAMEPLAYTIME INT, GAMEGB INT, GAMEPRICE DOUBLE, GAMETAGS VARCHAR(255), GAMEUSERSCORE VARCHAR(255))";

                try {
                        conn = DriverManager.getConnection(connectionURL);
                        stm = conn.createStatement();
                        myResult1 = conn.getMetaData().getTables(null, null, "CUST", null);
                        myResult2 = conn.getMetaData().getTables(null, null, "DEV", null);
                        myResult3 = conn.getMetaData().getTables(null, null, "BACKEND", null);
                        myResult4 = conn.getMetaData().getTables(null, null, "GAME", null);

                        if (myResult1.next() || myResult2.next() || myResult3.next() || myResult4.next()) {
                                System.out.println("Tables already exist");
                        }
                        else {
                                stm.execute(createCust);
                                stm.execute(createDev);
                                stm.execute(createBackend);
                                stm.execute(createGame);
                                System.out.println("Tables are created");
                        }
                        conn.close();
                        stm.close();
                        myResult1.close();
                        myResult2.close();
                        myResult3.close();
                        myResult4.close();
                } catch (Throwable ex) {
                        System.out.println("... exception thrown:");
                        ex.printStackTrace(System.out);
                }

        }

        //ADD STUFF TO DATABASES----------------------------------------------------------------------------------------

        public static void addToDatabase(){
                String mainDatabase = "MAIN_DATABASE";
                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                Statement stm;
                Connection conn = null;
                PreparedStatement psstm;
                ResultSet myResult, myResult1;
                try {
                        conn = DriverManager.getConnection(connectionURL);
                        stm = conn.createStatement();
                        myResult = conn.getMetaData().getTables(null, null, "CUST", null);
                        myResult1 = stm.executeQuery("select ID from CUST");
                        if (!myResult.next())
                                System.out.println("Table does not exist");
                        else if(myResult1.next()) {
                                System.out.println("Table already populated");
                        }
                        else {
                                psstm = conn.prepareStatement("INSERT into CUST (ID, NAME, TAGS) VALUES (?,?,?)");
                                psstm.setInt(1, 1234);
                                psstm.setString(2, "Jimmy");
                                psstm.setString(3, "Open World,Adventure,Sandbox,Survival");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into CUST (ID, NAME, TAGS) VALUES (?,?,?)");
                                psstm.setInt(1, 7890);
                                psstm.setString(2, "Chucky");
                                psstm.setString(3, "im hungry, im sick of this, let me out");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into DEV (DEVID, OWNEDGAMES) VALUES (?,?)");
                                psstm.setInt(1, 4321);
                                psstm.setString(2, "Minecraft,Call Of Duty,Poker,GTAVI");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into BACKEND (BACKENDNAME) VALUES (?)");
                                psstm.setString(1, "Glen");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS, GAMEUSERSCORE) VALUES (?,?,?,?,?,?,?,?)");
                                psstm.setString(1, "Minecraft");
                                psstm.setDouble(2, 4.5);
                                psstm.setString(3, "E");
                                psstm.setInt(4, 120);
                                psstm.setInt(5, 4);
                                psstm.setInt(6, 30);
                                psstm.setString(7, "Open World,Adventure,Sandbox,Survival");
                                psstm.setString(8, "4,3,5,5,5,4,3,2,5");
                                psstm.executeUpdate();
                                stm.close();
                                psstm.close();
                                myResult.close();
                        }
                } catch (Exception e) {
                        System.out.println("...exception thrown:");
                        e.printStackTrace();
                }
        }
//USE WHEN TRYING TO ACCESS ARRAYS FROM DATABASES------------------------------------------------------------------------
//try (Statement stmt = conn.createStatement();
//        ResultSet rs = stmt.executeQuery(selectSQL)) {
//                while (rs.next()) {
//                        String gameList = rs.getString("BACKENDNAME");
//                        String[] model = gameList.split(",");
//                        for (String game : gamesArray) {
//                                System.out.println(game.trim()); // Prints each game name
//                        }
//                }
//        }
        

        // for the 'who are you' panel
        private static JPanel signInPanel;
        private static JLabel signInInfo;
        private static JButton customer, dev, backendUser;


        //----------FOR CUSTOMER PURPOSES ONLY--------------------------------------------------------------------------


        // for the customer login panel
        private static JPanel customerLogin;
        private static JLabel login_1;
        private static JTextField id1;
        private static JButton login1;
        private static JButton back1;

        // for the customer main panel
        private static JPanel customerMainScreen;
        private static JLabel tags, games;
        private static JTextField tagsEnter;
        private static JButton addTags, rent, buy, info, logout, removeTag;
        private static DefaultListModel<String> tagModel = new DefaultListModel<>();
        private static DefaultListModel<String> gameModel = new DefaultListModel<>();
        private static DefaultComboBoxModel<String> cbRemoveTags = new DefaultComboBoxModel<>();

        // for the customer info panel
        private static JPanel customerInfoPanel;
        private static JLabel infoTitle, custName, custScore, custRating, custPlaytime, custSize, custPrice, custTags, custReviews;
        private static JTextField disName, disScore, disRating, disPlaytime, disSize, disPrice;
        private static DefaultListModel<String> gameTagsInfo = new DefaultListModel<>();
        private static DefaultListModel<String> gameReview = new DefaultListModel<>();
        private static JButton backToMain;
        // need a list to display the tags of course

        //Customer Buy/Rent Page
        private static JPanel transactionPanel;
        private static JButton completeTransaction, cancel;
        private static JLabel transactionTitle, cardNumTitle, gameSelectionTitle, priceOfGameTitle;
        private static JTextField cardEntry, gameSelection, priceOfGame;


        //----------FOR DEVELOPER PURPOSES ONLY-----------------------------------------------------------------------------


        // for the dev login panel
        private static JPanel devLogin;
        private static JLabel login_3;
        private static JTextField id3;
        private static JButton login3;
        private static JButton back3;

        // for the dev main panel
        private static JPanel devMain;
        private static JLabel devMainLabel;
        private static DefaultListModel<String> ownedGamesModel = new DefaultListModel<>();
        private static JButton editGameButton, addGameButton, deleteGameButton, devLogout;

        // dev add/edit
        private static JPanel devGamePanel;
        private static JLabel devInfoTitle, devName, devScore, devRating, devPlaytime, devSize, devPrice, devTags, devReviews;
        private static JTextField devDisName, devDisScore, devDisRating, devDisPlaytime, devDisSize, devDisPrice,devEditAddTag;
        private static DefaultComboBoxModel<String> cbEditTagsModel = new DefaultComboBoxModel<>();
        private static DefaultListModel<String> devGameTags = new DefaultListModel<>();
        private static DefaultListModel<String> devGameReviews = new DefaultListModel<>();
        private static JButton devBackToMain, completeChanges, devAddToTags, devRemoveToTags;


        //----------FOR ADMIN PURPOSES ONLY-----------------------------------------------------------------------------


        // for the backend login panel
        private static JPanel backendLogin;
        private static JLabel login_2;
        private static JTextField id2;
        private static JButton login2;
        private static JButton back2;

        // for the backend main panel
        private static JPanel backendMainScreen;
        private static JLabel backendTitle;
        private static JTextField enterUser;
        private static JButton addUser, deleteUser, backendLogout, devPage, custPage, addDev;

        // for Add user panel
        private static JPanel addUserAdmin;
        private static JLabel enterName, enterId;
        private static JTextField newUserId, newUserName;
        private static JButton complete, backToAdminActions;

        // for Dev user panel
        private static JPanel addDevAdmin;
        private static JLabel enterDevId;
        private static JTextField newDevId;
        private static JButton devComplete, backToAdminActionsDev;


        //MAIN FUNCTION


        public static void main(String[] args)
        {
                f = new JFrame("Video Game Browser");
                f.setSize(700,700);
                Final_Project browser = new Final_Project();
                createDatabase();
                addToDatabase();
                browser.create(f);
                f.setVisible(true);

        }


        //Main Frame Creation


        public static void create (JFrame f)
        {
                Final_Project mylist = new Final_Project();
                cardLayout = new JPanel();
                cardLayout.setLayout(cardLayout4use);
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.anchor = GridBagConstraints.FIRST_LINE_START;
                gbc.weightx = 0.5;
                gbc.weighty = 0.5;
                gbc.gridwidth = 1;
                gbc.ipadx = 10;
                gbc.ipady = 20;
                gbc.fill = GridBagConstraints.BOTH;
                gbc.insets = new Insets(10,10,10,10);


                // for the Who are you panel
                signInPanel = new JPanel();
                signInInfo = new JLabel("Select sign in type");
                signInPanel.setBackground(Color.lightGray);
                customer = new JButton("Customer");
                backendUser = new JButton("Backend User");
                dev = new JButton("Developer");
                Border panelBorder11 = BorderFactory.createTitledBorder("Account type selection");
                signInPanel.setBorder(panelBorder11);
                signInPanel.setLayout(new GridBagLayout());
                signInInfo.setFont(labelFont);
                customer.setFont(labelFont);
                backendUser.setFont(labelFont);
                dev.setFont(labelFont);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.gridx = 1; gbc.gridy = 0; signInPanel.add(signInInfo, gbc);
                gbc.gridx = 1; gbc.gridy = 2; signInPanel.add(customer, gbc);
                gbc.gridx = 3; gbc.gridy = 2; signInPanel.add(dev, gbc);
                gbc.gridx = 5; gbc.gridy = 2; signInPanel.add(backendUser, gbc);


                //----------FOR CUSTOMER PURPOSES ONLY-----------------------------------------------------------------------------


                // for the customer login panel
                customerLogin = new JPanel();
                customerLogin.setLayout(new GridBagLayout());
                customerLogin.setBackground(customerColor);
                login_1 = new JLabel("What is your id?");
                login1 = new JButton("Log In");
                back1 = new JButton("Back");
                id1 = new JTextField(10);
                Border panelBorder = BorderFactory.createTitledBorder("Customer Login");
                customerLogin.setBorder(panelBorder);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.gridx = 1; gbc.gridy = 1;customerLogin.add(login_1,gbc);
                gbc.gridx = 2; gbc.gridy = 2;customerLogin.add(login1,gbc);
                gbc.gridx = 1; gbc.gridy = 2;customerLogin.add(id1, gbc);
                gbc.gridx = 2; gbc.gridy = 3;customerLogin.add(back1, gbc);

                // for the customer main/third page
                customerMainScreen = new JPanel();
                customerMainScreen.setLayout(new GridBagLayout());
                customerMainScreen.setBackground(customerColor);
                tags = new JLabel("Tags");
                games = new JLabel("Games");
                JList<String> tagsList = new JList<>(tagModel);
                tagsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                tagsList.setVisibleRowCount(10);
                JList<String> gamesList = new JList<>(gameModel);
                gamesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                gamesList.setVisibleRowCount(2);
                JComboBox<String> tagsToRemove = new JComboBox<>(cbRemoveTags);
                removeTag = new JButton("Remove");
                tagsEnter = new JTextField(10);
                addTags = new JButton("Add");
                rent = new JButton("Rent");
                buy = new JButton("Buy");
                info = new JButton("Info");
                logout = new JButton("Logout");
                gbc.fill = GridBagConstraints.HORIZONTAL;
                Border panelBorder2 = BorderFactory.createTitledBorder("Customer Home Page");
                customerMainScreen.setBorder(panelBorder2);
                gbc.gridx = 1; gbc.gridy = 0;customerMainScreen.add(tags, gbc);
                gbc.gridx = 6; gbc.gridy = 0;customerMainScreen.add(games, gbc);
                gbc.gridx = 1; gbc.gridy = 1;customerMainScreen.add(tagsList, gbc);
                gbc.gridx = 6; gbc.gridy = 1;customerMainScreen.add(gamesList, gbc);
                gbc.gridx = 1; gbc.gridy = 4;customerMainScreen.add(tagsEnter, gbc);
                gbc.gridx = 3; gbc.gridy = 4;customerMainScreen.add(addTags, gbc);
                gbc.gridx = 1; gbc.gridy = 5;customerMainScreen.add(tagsToRemove, gbc);
                gbc.gridx = 3; gbc.gridy = 5;customerMainScreen.add(removeTag, gbc);
                gbc.gridx = 5; gbc.gridy = 4;customerMainScreen.add(rent, gbc);
                gbc.gridx = 6; gbc.gridy = 4;customerMainScreen.add(buy, gbc);
                gbc.gridx = 7; gbc.gridy = 4;customerMainScreen.add(info, gbc);
                gbc.gridx = 5; gbc.gridy = 6;customerMainScreen.add(logout, gbc);

                // for the customer info screen
                customerInfoPanel = new JPanel();
                customerInfoPanel.setBackground(customerColor);
                customerInfoPanel.setLayout(new GridBagLayout());
                infoTitle = new JLabel("INFO: ");
                custName = new JLabel("Name: ");
                custScore = new JLabel("Score: ");
                custRating = new JLabel("Rating: ");
                custPlaytime = new JLabel("Playtime: ");
                custSize = new JLabel("Size: ");
                custPrice = new JLabel("Price: ");
                custTags = new JLabel("Tags: ");
                custReviews = new JLabel("Reviews: ");
                disName = new JTextField(10);
                disName.setEditable(false);
                disScore = new JTextField(10);
                disScore.setEditable(false);
                disRating = new JTextField(10);
                disRating.setEditable(false);
                disPlaytime = new JTextField(10);
                disPlaytime.setEditable(false);
                disSize = new JTextField(10);
                disSize.setEditable(false);
                disPrice = new JTextField(10);
                disPrice.setEditable(false);
                JList<String> disReviews = new JList<>(gameReview);
                JList<String> tagsDisplay = new JList<>(gameTagsInfo);
                Border panelBorder3 = BorderFactory.createTitledBorder("Customer Info");
                customerInfoPanel.setBorder(panelBorder3);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                backToMain = new JButton("Back");
                gbc.gridx = 1; gbc.gridy = 0;
                customerInfoPanel.add(infoTitle, gbc);
                gbc.gridx = 0; gbc.gridy = 1;
                customerInfoPanel.add(custName, gbc);
                gbc.gridx = 0; gbc.gridy = 3;
                customerInfoPanel.add(custScore, gbc);
                gbc.gridx = 0; gbc.gridy = 5;
                customerInfoPanel.add(custRating, gbc);
                gbc.gridx = 0; gbc.gridy = 7;
                customerInfoPanel.add(custPlaytime, gbc);
                gbc.gridx = 1; gbc.gridy = 1;
                customerInfoPanel.add(custSize, gbc);
                gbc.gridx = 1; gbc.gridy = 3;
                customerInfoPanel.add(custPrice, gbc);
                gbc.gridx = 1; gbc.gridy = 5;
                customerInfoPanel.add(custReviews, gbc);
                gbc.gridx = 1; gbc.gridy = 7;
                customerInfoPanel.add(custTags, gbc);
                gbc.gridx = 0; gbc.gridy = 2;
                customerInfoPanel.add(disName, gbc);
                gbc.gridx = 0; gbc.gridy = 4;
                customerInfoPanel.add(disScore, gbc);
                gbc.gridx = 0; gbc.gridy = 6;
                customerInfoPanel.add(disRating, gbc);
                gbc.gridx = 0; gbc.gridy = 8;
                customerInfoPanel.add(disPlaytime, gbc);
                gbc.gridx = 1; gbc.gridy = 2;
                customerInfoPanel.add(disSize, gbc);
                gbc.gridx = 1; gbc.gridy = 4;
                customerInfoPanel.add(disPrice, gbc);
                gbc.gridx = 1; gbc.gridy = 6;
                customerInfoPanel.add(disReviews, gbc);
                gbc.gridx = 1; gbc.gridy = 8;
                customerInfoPanel.add(tagsDisplay, gbc);
                gbc.gridx = 2; gbc.gridy = 4;
                customerInfoPanel.add(backToMain, gbc);

                // Customer Transaction Panel
                transactionPanel = new JPanel();
                transactionPanel.setBackground(customerColor);
                transactionPanel.setLayout(new GridBagLayout());
                completeTransaction = new JButton("Continue");
                cancel = new JButton("Cancel");
                transactionTitle = new JLabel("Transaction Page");
                cardNumTitle = new JLabel("Input Card Number");
                gameSelection = new JTextField(10);
                gameSelectionTitle = new JLabel("Selected Game");
                Border panelBorder4 = BorderFactory.createTitledBorder("Customer Transaction");
                transactionPanel.setBorder(panelBorder4);
                cardEntry = new JTextField();
                priceOfGame = new JTextField();
                priceOfGameTitle = new JLabel("Price: ");
                gbc.gridx = 0; gbc.gridy = 4; // good
                transactionPanel.add(completeTransaction, gbc);
                gbc.gridx = 2; gbc.gridy = 4; // good
                transactionPanel.add(cancel, gbc);

                gbc.gridx = 0; gbc.gridy = 0;
                transactionPanel.add(transactionTitle, gbc); // good

                gbc.gridx = 0; gbc.gridy = 1;
                transactionPanel.add(gameSelectionTitle, gbc);
                gbc.gridx = 2; gbc.gridy = 1;
                transactionPanel.add(gameSelection, gbc);

                gbc.gridx = 2; gbc.gridy = 2;
                transactionPanel.add(priceOfGame, gbc);
                gbc.gridx = 0; gbc.gridy = 2;
                transactionPanel.add(priceOfGameTitle, gbc);

                gbc.gridx = 0; gbc.gridy = 3;
                transactionPanel.add(cardNumTitle, gbc);
                gbc.gridx = 2; gbc.gridy = 3;
                transactionPanel.add(cardEntry, gbc);



                //----------FOR DEVELOPERS PURPOSES ONLY-----------------------------------------------------------------------------


                // for the dev login panel
                devLogin = new JPanel();
                devLogin.setBackground(devColor);
                devLogin.setLayout(new GridBagLayout());
                login_2 = new JLabel("What is your id?");
                login2 = new JButton("Log In");
                id2 = new JTextField(10);
                back2 = new JButton("Back");
                Border panelBorder5 = BorderFactory.createTitledBorder("Developer Login");
                devLogin.setBorder(panelBorder5);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.gridx = 1; gbc.gridy = 1; devLogin.add(login_2, gbc);
                gbc.gridx = 2; gbc.gridy = 2; devLogin.add(login2, gbc);
                gbc.gridx = 1; gbc.gridy = 2; devLogin.add(id2, gbc);
                gbc.gridx = 2; gbc.gridy = 3; devLogin.add(back2, gbc);

                // for the dev main/third page
                devMain = new JPanel();
                devMain.setBackground(devColor);
                devMain.setLayout(new GridBagLayout());
                devMainLabel = new JLabel("Developer Main Screen");
                JList<String> ownedGames = new JList<>(ownedGamesModel);
                editGameButton = new JButton("Edit Game");
                addGameButton = new JButton("Add Game");
                deleteGameButton = new JButton("Delete Game");
                devLogout = new JButton("Logout");
                Border panelBorder6 = BorderFactory.createTitledBorder("Developer Home Page");
                devMain.setBorder(panelBorder6);
                gbc.gridx = 1; gbc.gridy = 2;
                devMain.add(ownedGames, gbc);
                gbc.gridx = 2; gbc.gridy = 2;
                devMain.add(editGameButton, gbc);
                gbc.gridx = 2; gbc.gridy = 1;
                devMain.add(addGameButton, gbc);
                gbc.gridx = 2; gbc.gridy = 3;
                devMain.add(deleteGameButton, gbc);
                gbc.gridx = 1; gbc.gridy = 5;
                devMain.add(devLogout, gbc);

                // Dev Add/Edit game Panel
                devGamePanel = new JPanel();
                devGamePanel.setBackground(devColor);
                devGamePanel.setLayout(new GridBagLayout());
                devInfoTitle = new JLabel("INFO: ");
                devName = new JLabel("Name: ");
                devScore = new JLabel("Score: ");
                devRating = new JLabel("Rating: ");
                devPlaytime = new JLabel("Playtime: ");
                devSize = new JLabel("Size: ");
                devPrice = new JLabel("Price: ");
                devTags = new JLabel("Tags: ");
                devReviews = new JLabel("Individual User Scores: ");
                devDisName = new JTextField(10);
                devDisScore = new JTextField(10);
                devDisRating = new JTextField(10);
                devDisPlaytime = new JTextField(10);
                devDisSize = new JTextField(10);
                devDisPrice = new JTextField(10);
                devEditAddTag = new JTextField(10);
                devBackToMain = new JButton("Back");
                completeChanges = new JButton("Complete");
                devAddToTags = new JButton("Add");
                devRemoveToTags = new JButton("Remove");
                JList<String> devTagsDisplay = new JList<>(devGameTags);
                JList<String> devReviewDisplay = new JList<>(devGameReviews);
                JComboBox<String> cbEditTags = new JComboBox<>(cbEditTagsModel);
                devBackToMain = new JButton("Back");
                Border panelBorder7 = BorderFactory.createTitledBorder("Developer Canvas");
                devGamePanel.setBorder(panelBorder7);
                gbc.gridx = 1; gbc.gridy = 0;
                devGamePanel.add(devInfoTitle, gbc);
                gbc.gridx = 0; gbc.gridy = 1;
                devGamePanel.add(devName, gbc);
                gbc.gridx = 0; gbc.gridy = 3;
                devGamePanel.add(devScore, gbc);
                gbc.gridx = 0; gbc.gridy = 5;
                devGamePanel.add(devRating, gbc);
                gbc.gridx = 0; gbc.gridy = 7;
                devGamePanel.add(devPlaytime, gbc);
                gbc.gridx = 1; gbc.gridy = 1;
                devGamePanel.add(devSize, gbc);
                gbc.gridx = 1; gbc.gridy = 3;
                devGamePanel.add(devPrice, gbc);
                gbc.gridx = 1; gbc.gridy = 5;
                devGamePanel.add(devReviews, gbc);

                gbc.gridx = 1; gbc.gridy = 7;
                devGamePanel.add(devTags, gbc);
                gbc.gridx = 2; gbc.gridy = 7;
                devGamePanel.add(devEditAddTag, gbc);
                gbc.gridx = 3; gbc.gridy = 7;
                devGamePanel.add(devAddToTags, gbc);

                gbc.gridx = 2; gbc.gridy = 8;
                devGamePanel.add(cbEditTags, gbc);
                gbc.gridx = 3; gbc.gridy = 8;
                devGamePanel.add(devRemoveToTags, gbc);

                gbc.gridx = 0; gbc.gridy = 2;
                devGamePanel.add(devDisName, gbc);
                gbc.gridx = 0; gbc.gridy = 4;
                devGamePanel.add(devDisScore, gbc);
                gbc.gridx = 0; gbc.gridy = 6;
                devGamePanel.add(devDisRating, gbc);
                gbc.gridx = 0; gbc.gridy = 8;
                devGamePanel.add(devDisPlaytime, gbc);
                gbc.gridx = 1; gbc.gridy = 2;
                devGamePanel.add(devDisSize, gbc);
                gbc.gridx = 1; gbc.gridy = 4;
                devGamePanel.add(devDisPrice, gbc);
                gbc.gridx = 1; gbc.gridy = 6;
                devGamePanel.add(devReviewDisplay, gbc);
                gbc.gridx = 1; gbc.gridy = 8;
                devGamePanel.add(devTagsDisplay, gbc);
                gbc.gridx = 3; gbc.gridy = 4;
                devGamePanel.add(devBackToMain, gbc);
                gbc.gridx = 3; gbc.gridy = 5;
                devGamePanel.add(completeChanges, gbc);


//----------------------FOR ADMIN ONLY----------------------------------------------------------------------------------


                // for the backend login panel
                backendLogin = new JPanel();
                backendLogin.setLayout(new GridBagLayout());
                backendLogin.setBackground(adminColor);
                login_3 = new JLabel("What is your id?");
                login3 = new JButton("Log In");
                back3 = new JButton("Back");
                id3 = new JTextField(10);
                Border panelBorder8 = BorderFactory.createTitledBorder("Administrator Login");
                backendLogin.setBorder(panelBorder8);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.gridx = 1; gbc.gridy = 1; backendLogin.add(login_3, gbc);
                gbc.gridx = 2; gbc.gridy = 2; backendLogin.add(login3, gbc);
                gbc.gridx = 1; gbc.gridy = 2; backendLogin.add(id3, gbc);
                gbc.gridx = 2; gbc.gridy = 3; backendLogin.add(back3, gbc);

                // for the backend main/third page
                backendMainScreen = new JPanel();
                backendMainScreen.setBackground(adminColor);
                backendMainScreen.setLayout(new GridBagLayout());
                backendTitle = new JLabel("Admin Actions:");
                addUser = new JButton("Add User");
                deleteUser = new JButton("Delete ID");
                devPage = new JButton("Developer Homepage");
                custPage = new JButton("Customer Homepage");
                enterUser = new JTextField(20);
                backendLogout = new JButton("Log Out");
                addDev = new JButton("Add Developer");
                Border panelBorder9 = BorderFactory.createTitledBorder("Administrator Main");
                backendMainScreen.setBorder(panelBorder9);
                gbc.gridx = 1; gbc.gridy = 0;
                backendMainScreen.add(backendTitle, gbc);
                gbc.gridx = 0; gbc.gridy = 3;
                backendMainScreen.add(addUser, gbc);
                gbc.gridx = 0; gbc.gridy = 4;
                backendMainScreen.add(custPage, gbc);
                gbc.gridx = 1; gbc.gridy = 2;
                backendMainScreen.add(deleteUser, gbc);
                gbc.gridx = 2; gbc.gridy = 4;
                backendMainScreen.add(devPage, gbc);
                gbc.gridx = 2; gbc.gridy = 3;
                backendMainScreen.add(addDev, gbc);
                gbc.gridx = 1; gbc.gridy = 1;
                backendMainScreen.add(enterUser, gbc);
                gbc.gridx = 2; gbc.gridy = 5;
                backendMainScreen.add(backendLogout, gbc);

                // Add User
                addUserAdmin = new JPanel();
                addUserAdmin.setBackground(adminColor);
                addUserAdmin.setLayout(new GridBagLayout());
                enterName = new JLabel("Name: ");
                enterId = new JLabel("ID: ");
                complete = new JButton("Complete");
                newUserId = new JTextField();
                newUserName = new JTextField();
                backToAdminActions = new JButton("Back");
                Border panelBorder10 = BorderFactory.createTitledBorder("Administer Canvas");
                gbc.fill = GridBagConstraints.HORIZONTAL;
                addUserAdmin.setBorder(panelBorder10);
                gbc.gridx = 0; gbc.gridy = 0;
                addUserAdmin.add(enterName, gbc);
                gbc.gridx = 0; gbc.gridy = 1;
                addUserAdmin.add(newUserName, gbc);
                gbc.gridx = 1; gbc.gridy = 0;
                addUserAdmin.add(enterId, gbc);
                gbc.gridx = 1; gbc.gridy = 1;
                addUserAdmin.add(newUserId, gbc);
                gbc.gridx = 0; gbc.gridy = 2;
                addUserAdmin.add(complete, gbc);
                gbc.gridx = 1; gbc.gridy = 2;
                addUserAdmin.add(backToAdminActions, gbc);
                
                //Add dev
                addDevAdmin = new JPanel();
                addDevAdmin.setBackground(adminColor);
                addDevAdmin.setLayout(new GridBagLayout());
                enterDevId = new JLabel("Enter New Dev Id");
                newDevId = new JTextField();
                devComplete = new JButton("Complete");
                backToAdminActionsDev = new JButton("Back");
                Border panelBorder12 = BorderFactory.createTitledBorder("Administer Canvas");
                addDevAdmin.setBorder(panelBorder12);
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.gridx = 0; gbc.gridy = 0;
                addDevAdmin.add(enterDevId, gbc);
                gbc.gridx = 0; gbc.gridy = 1;
                addDevAdmin.add(newDevId, gbc);
                gbc.gridx = 1; gbc.gridy = 1;
                addDevAdmin.add(devComplete, gbc);
                gbc.gridx = 1; gbc.gridy = 2;
                addDevAdmin.add(backToAdminActionsDev, gbc);

                //Add all to the main panel
                f.add(cardLayout);
                cardLayout.add(signInPanel, "1");
                cardLayout.add(customerLogin, "2");
                cardLayout.add(devLogin, "3");
                cardLayout.add(backendLogin, "4");
                cardLayout.add(customerMainScreen, "5");
                cardLayout.add(devMain, "6");
                cardLayout.add(backendMainScreen, "7");
                cardLayout.add(customerInfoPanel, "8");
                cardLayout.add(transactionPanel, "9");
                cardLayout.add(devGamePanel, "10");
                cardLayout.add(addUserAdmin, "11");
                cardLayout.add(addDevAdmin, "12");


                // Action listeners for the Who Are you Page

// leave as is, no SQL
                customer.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "2");
                        }
                });
                dev.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "3");
                        }
                });
                backendUser.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "4");
                        }
                });

                //Action Lister for the Back Buttons and other Buttons in Login Screens
                // SQL IS NOT NEEDED HERE
                back1.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "1");
                        }
                });
                back2.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "1");
                        }
                });
                back3.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "1");
                        }
                });


                login1.addActionListener(new ActionListener() {
                        String mainDatabase = "MAIN_DATABASE";
                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                        Statement stm;
                        Connection conn = null;
                        PreparedStatement psstm;
                        public void actionPerformed(ActionEvent e) {
                                if (id1.getText().equals("")) {
                                        JOptionPane.showMessageDialog(null, "Enter a valid ID");
                                }
                                else{
                                        ResultSet myResult, myResult1, myResult2;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                myResult = stm.executeQuery("select ID from CUST where ID="+id1.getText());
                                                user = id1.getText();
                                                if(!myResult.next())
                                                {
                                                        JOptionPane.showMessageDialog(null, "Invalid Login");
                                                }
                                                else {
                                                        cardLayout4use.show(cardLayout, "5");
                                                        tagModel.clear();
                                                        gameModel.clear();
                                                        cbRemoveTags.removeAllElements();
                                                        gameTagsInfo.clear();
                                                        id1.setText("");
                                                        myResult1 = stm.executeQuery("select * from CUST where ID = "+ user);
                                                        String[] tags = new String[0];
                                                        while(myResult1.next()){
                                                                String tagsList = myResult1.getString("TAGS");
                                                                if(tagsList.equals(null)){
                                                                        System.out.println("minor error");
                                                                }
                                                                else{
                                                                        tags = tagsList.split(",");
                                                                        for (String eachTag : tags ){
                                                                                tagModel.addElement(eachTag);
                                                                                cbRemoveTags.addElement(eachTag);
                                                                        }
                                                                }
                                                        }
                                                        ArrayList<String> validGames = new ArrayList<String>();
                                                        myResult2 = stm.executeQuery("select * from GAME");
                                                        while(myResult2.next()){
                                                                String temp = myResult2.getString("GAMETAGS");
                                                                String tempName = myResult2.getString("GAMENAME");
//                                                        String [] tempGameTags = temp.split(",");
//                                                        for(String gametag : tempGameTags){
//                                                                for(String tempGameTag : tags)
//                                                                        if(gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())){
//                                                                                    validGames.add(tempName);
//                                                                        }
//                                                                }
                                                                if (temp != null) { // Check if temp is not null
                                                                        String[] tempGameTags = temp.split(",");
                                                                        for (String gametag : tempGameTags) {
                                                                                for (String tempGameTag : tags) {
                                                                                        if (gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())) {
                                                                                                validGames.add(tempName);
                                                                                        }
                                                                                }
                                                                        }
                                                                } else {
                                                                        System.out.println("Skipping game with null tags: " + tempName);
                                                                }

                                                        }
                                                        for (String game : validGames){
                                                                gameModel.addElement(game);
                                                        }
                                                        validGames.clear();
                                                        tags = new String[0];
                                                        stm.close();
                                                        myResult.close();
                                                        myResult1.close();
                                                        myResult2.close();
                                                }
                                                //  myResult1 = stm.executeQuery("select PSU_ID, NAME, GENDER from STUD");
                                        } catch (Exception ex)
                                        {
                                                System.out.println("something Went Wrong");
                                                ex.printStackTrace();
                                        }
                                }

                        }
                });
                login2.addActionListener(new ActionListener() {
                        String mainDatabase = "MAIN_DATABASE";
                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                        Statement stm;
                        Connection conn = null;
                        PreparedStatement psstm;
                        public void actionPerformed(ActionEvent e) {
                                if (!id2.getText().isEmpty()) {
                                        ResultSet myResult, myResult1, myResult2 = null;
                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                myResult = stm.executeQuery("select DEVID from DEV where DEVID=" + id2.getText());
                                                if (!myResult.next()) {
                                                        JOptionPane.showMessageDialog(null, "Invalid Login");
                                                } else {
                                                        ownedGamesModel.clear();
                                                        devGameTags.clear();
                                                        developer = Integer.valueOf(id2.getText());
                                                        id2.setText("");
                                                        cardLayout4use.show(cardLayout, "6");


                                                        myResult1 = stm.executeQuery("select * from DEV where DEVID = " + developer);
                                                        String[] games = new String[0];
                                                        ownedGamesModel.clear();
                                                        while (myResult1.next()) {

                                                                String gamesList = myResult1.getString("OWNEDGAMES");
                                                                games = gamesList.split(",");
                                                                for (String eachGame : games) {
                                                                        ownedGamesModel.addElement(eachGame);
                                                                }
                                                        }
                                                        games = new String[0];
                                                        stm.close();
                                                        myResult.close();
                                                        myResult1.close();
                                                }
                                        } catch (Exception ex) {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                                }
                                else {
                                        JOptionPane.showMessageDialog(null, "Enter a valid ID");
                                }
                        }
                });
                login3.addActionListener(new ActionListener() {
                        String mainDatabase = "MAIN_DATABASE";
                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                        Statement stm;
                        Connection conn = null;
                        PreparedStatement psstm = null;
                        ResultSet myResult;
                        public void actionPerformed (ActionEvent e){
                                try {
                                        conn = DriverManager.getConnection(connectionURL);
                                        stm = conn.createStatement();
                                        psstm = conn.prepareStatement("select BACKENDNAME from BACKEND where BACKENDNAME = ?");
                                        psstm.setString(1, id3.getText());
                                        myResult = psstm.executeQuery();
                                        if (!myResult.next() || id3.getText().equals("")) {
                                                JOptionPane.showMessageDialog(null, "Enter a valid ID");
                                        } else {
                                                cardLayout4use.show(cardLayout, "7");
                                        }
                                        id3.setText("");
                                        psstm.close();
                                        stm.close();
                                        conn.close();
                                        myResult.close();

                                } catch (Exception ex) {
                                        System.out.println("ERROR");
                                        ex.printStackTrace();
                                }
                        }
                });


                //Customer Main Screen Buttons


                info.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                                if(gamesList.getSelectedValue() == null){
                                        JOptionPane.showMessageDialog(null, "Please select a game. If none are available, change your tags");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm = null;
                                        Connection conn = null;
                                        ResultSet myResult = null, myResult1 = null, myResult2 = null;
                                        String Subject = gamesList.getSelectedValue();
                                        ArrayList<Double> arrayScores = new ArrayList<Double>();
                                        Double scoresStorage = 0.0;
                                        gameReview.clear();
                                        gameTagsInfo.clear();
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();


                                                PreparedStatement psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, gamesList.getSelectedValue());
                                                myResult = psstm.executeQuery();
                                                if(myResult.next()){
                                                        disName.setText(myResult.getString("GAMENAME"));
                                                        disRating.setText(myResult.getString("GAMERATING"));
                                                        disPlaytime.setText(myResult.getString("GAMEPLAYTIME"));
                                                        disSize.setText(myResult.getString("GAMEGB"));
                                                        disPrice.setText(myResult.getString("GAMEPRICE"));
                                                }
                                                PreparedStatement psstm2 = conn.prepareStatement("select GAMETAGS, GAMEUSERSCORE from GAME where GAMENAME = ?");
                                                psstm2.setString(1, gamesList.getSelectedValue());
                                                myResult1 = psstm2.executeQuery();
                                                while (myResult1.next())
                                                {
                                                        String tagsList = myResult1.getString("GAMETAGS");
                                                        String [] gameTagsInTb = tagsList.split(",");
                                                        for (String eachTag : gameTagsInTb ){
                                                                gameTagsInfo.addElement(eachTag);
                                                        }

                                                        String scoresList = myResult1.getString("GAMEUSERSCORE");
                                                        if(scoresList != null)
                                                        {
                                                                String[] scores = scoresList.split(",");
                                                                for (String eachScore : scores){
                                                                        arrayScores.add(Double.valueOf(eachScore));
                                                                }
                                                        }
                                                }
                                                if(!arrayScores.isEmpty())
                                                {
                                                        for(int i = 0; i < arrayScores.size(); i++){
                                                                scoresStorage += arrayScores.get(i);
                                                                gameReview.addElement(String.valueOf(arrayScores.get(i)));
                                                        }
                                                        scoresStorage /= arrayScores.size();
                                                }
                                                disScore.setText(String.valueOf(scoresStorage));

                                                scoresStorage = 0.0;
                                                arrayScores.clear();
                                                psstm.close();
                                                psstm2.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();
                                                myResult1.close();

                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                        finally{
                                                cardLayout4use.show(cardLayout, "8");
                                        }
                                }
                        }
                });
                // done for both buy and rent
                buy.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (gamesList.getSelectedValue() == null)
                                {
                                        JOptionPane.showMessageDialog(null, "Select a game to proceed to transaction");
                                }
                                else {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm;
                                        Connection conn = null;
                                        PreparedStatement psstm = null;
                                        ResultSet myResult;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, gamesList.getSelectedValue());
                                                myResult = psstm.executeQuery();
                                                if(myResult.next())
                                                priceOfGame.setText("$" + myResult.getString("GAMEPRICE"));

                                                psstm.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();

                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        } finally {
                                                cardLayout4use.show(cardLayout, "9");
                                                gameSelection.setText(gamesList.getSelectedValue());
                                        }
                                };
                                }

                });
                rent.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (gamesList.getSelectedValue() == null)
                                {
                                        JOptionPane.showMessageDialog(null, "Select a game to proceed to transaction");
                                }
                                else {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm;
                                        Connection conn = null;
                                        PreparedStatement psstm = null;
                                        ResultSet myResult;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, gamesList.getSelectedValue());
                                                myResult = psstm.executeQuery();

                                                if(myResult.next())
                                                        priceOfGame.setText("$" + myResult.getString("GAMEPRICE"));

                                                psstm.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();
                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        } finally {
                                                cardLayout4use.show(cardLayout, "9");
                                                gameSelection.setText(gamesList.getSelectedValue());
                                        }
                                };
                        }

                });
                addTags.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (tagsEnter.getText() == null)
                                {
                                        JOptionPane.showMessageDialog(null, "Please enter a tag");
                                }
                                else if (tagModel.contains((tagsEnter.getText()).trim())){ // needs insensitive testing
                                        JOptionPane.showMessageDialog(null, "The tag you are trying to enter already exists");
                                }
                                else {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm, stm2, stm3;
                                        Connection conn = null;
                                        PreparedStatement psstm = null;
                                        ResultSet myResult, myResult1, myResult2;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                tagModel.addElement(tagsEnter.getText());
                                                cbRemoveTags.addElement(tagsEnter.getText());
                                                StringBuilder longArrayTags = new StringBuilder();
                                                for(int i = 0; i < tagModel.size(); i++){
                                                        longArrayTags.append(tagModel.getElementAt(i));
                                                        if(i < tagModel.size() - 1)
                                                                longArrayTags.append(",");
                                                }
                                                String strToSend = longArrayTags.toString();
                                                psstm = conn.prepareStatement("UPDATE CUST SET TAGS = (?) WHERE ID = " + user);

                                                psstm.setString(1, strToSend);
                                                psstm.executeUpdate();

                                                // now update the model of games depending on the tags again
                                                //--------------------------------
                                                System.out.println("made it to where the rerendering happens");
                                                stm2 = conn.createStatement();
                                                myResult = stm2.executeQuery("select ID from CUST where ID=" + user);
                                                if (!myResult.next()) {
                                                        JOptionPane.showMessageDialog(null, "Invalid Login");
                                                } else {
                                                        tagModel.clear();
                                                        gameModel.clear();
                                                        cbRemoveTags.removeAllElements();
                                                        gameTagsInfo.clear();
                                                        System.out.println(user);
                                                        stm3 = conn.createStatement();
                                                        myResult1 = stm3.executeQuery("select * from CUST where ID=" + user);
                                                        String[] tags = new String[0];
                                                        while (myResult1.next()) {
                                                                String tagsList = myResult1.getString("TAGS");
                                                                tags = tagsList.split(",");
                                                                for (String eachTag : tags) {
                                                                        tagModel.addElement(eachTag);
                                                                        cbRemoveTags.addElement(eachTag);
                                                                }
                                                        }
                                                        ArrayList<String> validGames = new ArrayList<String>();
                                                        myResult2 = stm.executeQuery("select * from GAME");
                                                        while (myResult2.next()) {
                                                                String temp = myResult2.getString("GAMETAGS");
                                                                String tempName = myResult2.getString("GAMENAME");
                                                                String[] tempGameTags = temp.split(",");
                                                                for (String gametag : tempGameTags) {
                                                                        for (String tempGameTag : tags)
                                                                                if (gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())) {
                                                                                        validGames.add(tempName);
                                                                                }
                                                                }

                                                        }
                                                        for (String game : validGames) {
                                                                gameModel.addElement(game);
                                                        }
                                                        validGames.clear();
                                                        tags = new String[0];
                                                        myResult.close();
                                                        myResult1.close();
                                                        myResult2.close();
                                                        //---------------------------------
                                                        psstm.close();
                                                        stm.close();
                                                        conn.close();
                                                        stm2.close();
                                                        stm3.close();
                                                }
                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        } finally {
                                                tagsEnter.setText("");
                                        }
                                }
                                }
                });
                removeTag.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                String mainDatabase = "MAIN_DATABASE";
                                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                Statement stm, stm2, stm3;
                                Connection conn = null;
                                PreparedStatement psstm = null;
                                ResultSet myResult, myResult1, myResult2;
                                try {
                                        conn = DriverManager.getConnection(connectionURL);
                                        stm = conn.createStatement();
                                        tagModel.removeElement(tagsToRemove.getSelectedItem());
                                        cbRemoveTags.removeElement(tagsToRemove.getSelectedItem());
                                        // coverting an array to string with dem commas
                                        StringBuilder longArrayTags = new StringBuilder();
                                        for (int i = 0; i < tagModel.size(); i++) {
                                                longArrayTags.append(tagModel.getElementAt(i));
                                                if (i < tagModel.size() - 1)
                                                        longArrayTags.append(",");
                                        }
                                        String strToSend = longArrayTags.toString();
                                        psstm = conn.prepareStatement("UPDATE CUST SET TAGS = (?) WHERE ID = " + user);
                                        psstm.setString(1, strToSend);
                                        psstm.executeUpdate();

                                        // now update the model of games depending on the tags again
                                        //--------------------------------
                                        stm2 = conn.createStatement();
                                        myResult = stm2.executeQuery("select ID from CUST where ID=" + user);
                                        if (!myResult.next()) {
                                                JOptionPane.showMessageDialog(null, "Invalid Login");
                                        } else {
                                                tagModel.clear();
                                                gameModel.clear();
                                                cbRemoveTags.removeAllElements();
                                                gameTagsInfo.clear();
                                                stm3 = conn.createStatement();
                                                myResult1 = stm3.executeQuery("select * from CUST where ID=" + user);
                                                String[] tags = new String[0];
                                                while (myResult1.next()) {
                                                        String tagsList = myResult1.getString("TAGS");
                                                        tags = tagsList.split(",");
                                                        for (String eachTag : tags) {
                                                                tagModel.addElement(eachTag);
                                                                cbRemoveTags.addElement(eachTag);
                                                        }
                                                }
                                                ArrayList<String> validGames = new ArrayList<String>();
                                                myResult2 = stm.executeQuery("select * from GAME");
                                                while (myResult2.next()) {
                                                        String temp = myResult2.getString("GAMETAGS");
                                                        String tempName = myResult2.getString("GAMENAME");
                                                        String[] tempGameTags = temp.split(",");
                                                        for (String gametag : tempGameTags) {
                                                                for (String tempGameTag : tags)
                                                                        if (gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())) {
                                                                                validGames.add(tempName);
                                                                        }
                                                        }

                                                }
                                                for (String game : validGames) {
                                                        gameModel.addElement(game);
                                                }
                                                validGames.clear();
                                                tags = new String[0];
                                                myResult.close();
                                                myResult1.close();
                                                myResult2.close();
                                                //---------------------------------
                                                psstm.close();
                                                stm2.close();
                                                conn.close();
                                                }
                                        } catch(Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                        }
                });
                completeTransaction.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (cardEntry.getText().trim().isEmpty())
                                {
                                        JOptionPane.showMessageDialog(null, "Please enter a valid card number");
                                }
                                else {
                                        JOptionPane.showMessageDialog(null, "Success!!");
                                        cardLayout4use.show(cardLayout, "5");
                                        cardEntry.setText("");
                                }
                        }
                });

                cancel.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "5"); }
                });

                backToMain.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "5"); }
                });

                logout.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "1");
                        user = null;}
                });
                
                
                //Dev Main Panel Buttons

// test this
                editGameButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                //ADD FILLING OR KEEPING THE BOXES EMPTY
                                if(ownedGames.getSelectedValue() == null){
                                        JOptionPane.showMessageDialog(null, "Please select a game to edit.");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm = null;
                                        Connection conn = null;
                                        ResultSet myResult = null, myResult1 = null;
                                        String subject = ownedGames.getSelectedValue();
                                        ArrayList<Double> arrayScores = new ArrayList<Double>();
                                        Double scoresStorage = 0.0;
                                        devGameTags.clear();
                                        devGameReviews.clear();
                                        cbEditTagsModel.removeAllElements();
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                PreparedStatement psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, ownedGames.getSelectedValue());
                                                myResult = psstm.executeQuery();
                                                if(myResult.next()){
                                                        devDisName.setText(myResult.getString("GAMENAME"));
                                                        devDisRating.setText(myResult.getString("GAMERATING"));
                                                        devDisPlaytime.setText(myResult.getString("GAMEPLAYTIME"));
                                                        devDisSize.setText(myResult.getString("GAMEGB"));
                                                        devDisPrice.setText(myResult.getString("GAMEPRICE"));
                                                }
                                                PreparedStatement psstm2 = conn.prepareStatement("select GAMETAGS, GAMEUSERSCORE from GAME where GAMENAME = ?");
                                                psstm2.setString(1, ownedGames.getSelectedValue());
                                                myResult1 = psstm2.executeQuery();
                                                while (myResult1.next())
                                                {
                                                        String devTagsDisplay = myResult1.getString("GAMETAGS");
                                                        String [] gameTagsInTb = devTagsDisplay.split(",");
                                                        for (String eachTag : gameTagsInTb ){
                                                                devGameTags.addElement(eachTag);
                                                                cbEditTagsModel.addElement(eachTag);
                                                        }

                                                        String scoresList = myResult1.getString("GAMEUSERSCORE");
                                                        if(scoresList != null)
                                                        {
                                                                String[] scores = scoresList.split(",");
                                                                for (String eachScore : scores){
                                                                        arrayScores.add(Double.valueOf(eachScore));
                                                                }
                                                        }
                                                }
                                                if(!arrayScores.isEmpty())
                                                {
                                                        for(int i = 0; i < arrayScores.size(); i++){
                                                                scoresStorage += arrayScores.get(i);
                                                                devGameReviews.addElement(String.valueOf(arrayScores.get(i)));
                                                        }
                                                        scoresStorage /= arrayScores.size();
                                                }
                                                devDisScore.setText(String.valueOf(scoresStorage));

                                                scoresStorage = 0.0;
                                                arrayScores.clear();
                                                psstm.close();
                                                psstm2.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();
                                                myResult1.close();

                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                        finally{
                                                add_edit = 0;
                                                cardLayout4use.show(cardLayout, "10");
                                        }
                                }
                        }
                });
                devAddToTags.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if(devEditAddTag.getText().trim().equals("") || devGameTags.contains(devEditAddTag.getText().trim())){
                                        JOptionPane.showMessageDialog(null, "Please enter a valid tag to add");
                                }else{
                                        devGameTags.addElement(devEditAddTag.getText().trim());
                                        devEditAddTag.setText("");
                                }
                        }
                });
                devRemoveToTags.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                devGameTags.removeElement(cbEditTags.getSelectedItem());
                                cbEditTagsModel.removeElement(cbEditTags.getSelectedItem());
                        }
                });
                completeChanges.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                String mainDatabase = "MAIN_DATABASE";
                                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                Connection conn = null;
                                ResultSet myResult1 = null, myResult2 = null;
                                if (add_edit == 0){
                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                PreparedStatement psstm3 = conn.prepareStatement("select * from DEV where DEVID = ?");
                                                psstm3.setInt(1, developer);
                                                myResult1 = psstm3.executeQuery();
                                                String str = null;
                                                if (myResult1.next()) {
                                                        String gamesList = myResult1.getString("OWNEDGAMES");
                                                        String[] temp = new String[0];
                                                        temp = gamesList.split(",");
                                                        StringBuilder newTemp = new StringBuilder();
                                                        for (int i = 0; i < temp.length; i++) {
                                                                if (temp[i].equals(ownedGames.getSelectedValue())) {
                                                                        newTemp.append(devDisName.getText() + ",");
                                                                } else {
                                                                        newTemp.append(temp[i]);
                                                                        if (i < temp.length - 1) {
                                                                                newTemp.append(",");
                                                                        }
                                                                }
                                                        }
                                                        str = newTemp.toString();
                                                }
                                                // converting the tagmodel into a string
                                                StringBuilder tagsForGame = new StringBuilder();
                                                for(int i = 0; i < devGameTags.size(); i++){
                                                        tagsForGame.append(devGameTags.getElementAt(i));
                                                        if(i < devGameTags.size() - 1)
                                                                tagsForGame.append(",");
                                                }
                                                String strToSend = tagsForGame.toString();

                                                PreparedStatement psstm1 = conn.prepareStatement("UPDATE GAME SET GAMENAME = ?, GAMESCORE = ?, GAMERATING = ?, GAMEPLAYTIME = ?, GAMEGB = ?, GAMEPRICE = ?, GAMETAGS = ? WHERE GAMENAME = ?");
                                                PreparedStatement psstm2 = conn.prepareStatement("UPDATE DEV SET OWNEDGAMES = ? WHERE DEVID = " + developer);
                                                psstm1.setString(8, ownedGames.getSelectedValue());
                                                psstm1.setString(1, devDisName.getText());
                                                psstm1.setDouble(2, Double.parseDouble(devDisScore.getText()));
                                                psstm1.setString(3, devDisRating.getText());
                                                psstm1.setInt(4, Integer.parseInt(devDisPlaytime.getText()));
                                                psstm1.setInt(5, Integer.parseInt(devDisSize.getText()));
                                                psstm1.setDouble(6, Double.parseDouble(devDisPrice.getText()));
                                                psstm1.setString(7, strToSend);
                                                psstm2.setString(1, str);
                                                psstm1.executeUpdate();
                                                psstm2.executeUpdate();

                                                ownedGamesModel.clear();
                                                String[] temp2 = str.split(",");
                                                for (String newGame : temp2) {
                                                        ownedGamesModel.addElement(newGame);
                                                }

                                                devDisName.setText("");
                                                devDisScore.setText("");
                                                devDisRating.setText("");
                                                devDisPlaytime.setText("");
                                                devDisSize.setText("");
                                                devDisPrice.setText("");
                                                psstm1.close();
                                                psstm2.close();
                                                psstm3.close();
                                                myResult1.close();
                                                conn.close();

                                        } catch (Exception ex) {
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        } finally {
                                                cardLayout4use.show(cardLayout, "6");
                                                JOptionPane.showMessageDialog(null, "Success!!");
                                        }
                                }
                                else{
                                        try {
                                                conn = DriverManager.getConnection(connectionURL);

                                                PreparedStatement psstm3 = conn.prepareStatement("select * from DEV where DEVID = ?");
                                                psstm3.setInt(1, developer);
                                                myResult1 = psstm3.executeQuery();
                                                String str = null;
                                                if (myResult1.next()) {
                                                        String gamesList = myResult1.getString("OWNEDGAMES");
                                                        String[] temp = new String[0];
                                                        temp = gamesList.split(",");
                                                        StringBuilder newTemp = new StringBuilder();
                                                        for (int i = 0; i < temp.length; i++) {
                                                                newTemp.append(temp[i]);
                                                                if (i < temp.length - 1) {
                                                                        newTemp.append(",");
                                                                }
                                                        }
                                                        newTemp.append("," + devDisName.getText());
                                                        str = newTemp.toString();
                                                }

                                                StringBuilder tagsForGame = new StringBuilder();
                                                for(int i = 0; i < devGameTags.size(); i++){
                                                        tagsForGame.append(devGameTags.getElementAt(i));
                                                        if(i < devGameTags.size() - 1)
                                                                tagsForGame.append(",");
                                                }
                                                String strToSend = tagsForGame.toString();

                                                PreparedStatement psstm2 = conn.prepareStatement("UPDATE DEV SET OWNEDGAMES = ? WHERE DEVID = " + developer);
                                                PreparedStatement psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS) VALUES (?,?,?,?,?,?,?)");
                                                Statement stm = conn.createStatement();
                                                String query = "SELECT GAMENAME FROM GAME";
                                                myResult1 = stm.executeQuery(query);
                                                boolean valid = true;
                                                while (myResult1.next()) {
                                                        if (devDisName.getText().equals(myResult1.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "Game already exists! please enter another name");
                                                                valid = false;
                                                        }
                                                }
                                                if (valid) {
                                                        psstm.setString(1, devDisName.getText());
                                                        psstm.setDouble(2, Double.parseDouble(devDisScore.getText()));
                                                        psstm.setString(3, devDisRating.getText());
                                                        psstm.setInt(4, Integer.parseInt(devDisPlaytime.getText()));
                                                        psstm.setInt(5, Integer.parseInt(devDisSize.getText()));
                                                        psstm.setDouble(6, Double.parseDouble(devDisPrice.getText()));
                                                        psstm.setString(7, strToSend);
                                                        psstm2.setString(1, str);
                                                        psstm.executeUpdate();
                                                        psstm2.executeUpdate();

                                                        ownedGamesModel.clear();
                                                        String[] temp2 = str.split(",");
                                                        for (String newGame : temp2) {
                                                                ownedGamesModel.addElement(newGame);
                                                        }

                                                        cardLayout4use.show(cardLayout, "6");
                                                        JOptionPane.showMessageDialog(null, "Success!!");
                                                }

                                                devDisName.setText("");
                                                devDisScore.setText("");
                                                devDisRating.setText("");
                                                devDisPlaytime.setText("");
                                                devDisSize.setText("");
                                                devDisPrice.setText("");
                                                myResult1.close();
                                                psstm.close();
                                                conn.close();
                                        }
                                        catch(Exception ex) {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                                }
                        }
                });
                addGameButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                // clearing all parts of the info page for safety
                                devDisPrice.setText("");
                                devDisSize.setText("");
                                devDisPlaytime.setText("");
                                devDisRating.setText("");
                                devDisScore.setText("");
                                devDisName.setText("");
                                devGameTags.clear();
                                devGameReviews.clear();
                                cbEditTagsModel.removeAllElements();
                                add_edit = 1;
                                // going to the panel
                                cardLayout4use.show(cardLayout, "10");
                        }
                });
                deleteGameButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                String mainDatabase = "MAIN_DATABASE";
                                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                Statement stm;
                                Connection conn = null;
                                ResultSet myResult1;
                                try{
                                        conn = DriverManager.getConnection(connectionURL);
                                        stm = conn.createStatement();

                                        PreparedStatement psstm3 = conn.prepareStatement("select * from DEV where DEVID = ?");
                                        psstm3.setInt(1, developer);
                                        myResult1 = psstm3.executeQuery();
                                        String str = null;
                                        if (myResult1.next()) {
                                                String gamesList = myResult1.getString("OWNEDGAMES");
                                                String[] temp = new String[0];
                                                temp = gamesList.split(",");
                                                StringBuilder newTemp = new StringBuilder();
                                                for (int i = 0; i < temp.length; i++) {
                                                        if (temp[i].equals(ownedGames.getSelectedValue())) {}
                                                        else {
                                                                newTemp.append(temp[i]);
                                                                if (i < temp.length - 1) {
                                                                        newTemp.append(",");
                                                                }
                                                        }
                                                }
                                                str = newTemp.toString();
                                        }



                                        PreparedStatement psstm = conn.prepareStatement("UPDATE DEV SET OWNEDGAMES = ? WHERE DEVID = " + developer);
                                        PreparedStatement psstm2 = conn.prepareStatement("DELETE FROM GAME WHERE GAMENAME = ?");
                                        psstm2.setString(1, ownedGames.getSelectedValue());
                                        int rowsAffected = psstm2.executeUpdate();

                                        if (rowsAffected > 0) {
                                                JOptionPane.showMessageDialog(null, "Record deleted successfully.");
                                        } else {
                                                JOptionPane.showMessageDialog(null, "No record found with the given game.");
                                        }

                                        psstm.setString(1, str);
                                        psstm.executeUpdate();

                                        ownedGamesModel.clear();
                                        String[] temp2 = str.split(",");
                                        for (String newGame : temp2) {
                                                ownedGamesModel.addElement(newGame);
                                        }

                                        psstm.close();
                                        psstm2.close();
                                        psstm3.close();
                                        myResult1.close();
                                        stm.close();
                                        conn.close();
                                }
                                catch (Exception ex)
                                {
                                        System.out.println("ERROR");
                                        ex.printStackTrace();
                                }
                        }
                });
                devLogout.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "1"); }
                });
                devBackToMain.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "6");
                                devDisName.setText("");
                                devDisScore.setText("");
                                devDisRating.setText("");
                                devDisPlaytime.setText("");
                                devDisSize.setText("");
                                devDisPrice.setText("");
                        }
                });


                //Backend main panel buttons


                addUser.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "11"); }
                });
                deleteUser.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                //DELETE USER FUNCTIONALLITY GOES HERE
                                if (!enterUser.getText().equals("")) {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm;
                                        Connection conn = null;
                                        ResultSet myResult;
                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                PreparedStatement psstm = conn.prepareStatement("DELETE FROM CUST WHERE ID = ?");
                                                PreparedStatement psstm2 = conn.prepareStatement("DELETE FROM DEV WHERE DEVID = ?");
                                                psstm.setString(1, enterUser.getText());
                                                psstm2.setString(1, enterUser.getText());
                                                int rowsAffected = psstm.executeUpdate();
                                                int rowsAffectedDev = psstm2.executeUpdate();

                                                if (rowsAffected > 0) {
                                                        JOptionPane.showMessageDialog(null, "Customer record deleted successfully.");
                                                }
                                                else if(rowsAffectedDev > 0){
                                                        JOptionPane.showMessageDialog(null, "Dev record deleted successfully.");
                                                }
                                                else {
                                                        JOptionPane.showMessageDialog(null, "No record found with the given ID.");
                                                }

                                                enterUser.setText("");
                                                stm.close();
                                                psstm.close();
                                                psstm2.close();
                                                conn.close();

                                        } catch (Exception ex) {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                                }
                                else{
                                        JOptionPane.showMessageDialog(null,"Enter an ID please");
                                }
                        }

                });
                custPage.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                tagModel.clear();
                                gameModel.clear();
                                cbRemoveTags.removeAllElements();
                                tagsEnter.setText("");
                                cardLayout4use.show(cardLayout, "5");
                        }
                });
                devPage.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                ownedGamesModel.clear();
                                cardLayout4use.show(cardLayout, "6");
                        }
                });
                backToAdminActions.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "7"); }
                });
                complete.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (newUserName.getText().equals("") || newUserId.getText().equals("")) {
                                        JOptionPane.showMessageDialog(null, "Please enter a name and an ID");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Connection conn = null;
                                        ResultSet myResult1 = null, myResult2 = null;

                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                PreparedStatement psstm = conn.prepareStatement("INSERT into CUST (ID, NAME, TAGS) VALUES (?,?,?)");
                                                Statement stm = conn.createStatement();
                                                Statement stm2 = conn.createStatement();
                                                String query = "SELECT ID FROM CUST";
                                                String query2 = "SELECT DEVID FROM DEV";
                                                myResult1 = stm.executeQuery(query);
                                                myResult2 = stm2.executeQuery(query2);
                                                boolean valid = true;
                                                while (myResult1.next()) {
                                                        if (newUserId.getText().equals(myResult1.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as customer! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                while (myResult2.next()) {
                                                        if (newUserId.getText().equals(myResult2.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as dev! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                if (valid) {
                                                        psstm.setInt(1, Integer.parseInt(newUserId.getText()));
                                                        psstm.setString(2, newUserName.getText());
                                                        psstm.setString(3, null);
                                                        psstm.executeUpdate();
                                                        cardLayout4use.show(cardLayout, "7");
                                                        JOptionPane.showMessageDialog(null, "Success!!");
                                                }

                                                newUserName.setText("");
                                                newUserId.setText("");
                                                psstm.close();
                                                conn.close();
                                        }
                                        catch(Exception ex){
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                }
                        }
                });
                backendLogout.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "1"); }
                });
                backToAdminActionsDev.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "7"); }
                });
                devComplete.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (newDevId.getText().equals("")) {
                                        JOptionPane.showMessageDialog(null, "Please enter an DEVID");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Connection conn = null;
                                        ResultSet myResult1 = null, myResult2 = null;

                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                PreparedStatement psstm = conn.prepareStatement("INSERT into DEV (DEVID, OWNEDGAMES) VALUES (?,?)");
                                                Statement stm = conn.createStatement();
                                                Statement stm2 = conn.createStatement();
                                                String query = "SELECT DEVID FROM DEV";
                                                String query2 = "SELECT ID FROM CUST";
                                                myResult1 = stm.executeQuery(query);
                                                myResult2 = stm2.executeQuery(query2);
                                                boolean valid = true;
                                                while (myResult1.next()) {
                                                        if (newDevId.getText().equals(myResult1.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as dev! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                while (myResult2.next()){
                                                        if (newDevId.getText().equals(myResult2.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as customer! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                if (valid) {
                                                        psstm.setInt(1, Integer.parseInt(newDevId.getText()));
                                                        psstm.setString(2,"");
                                                        psstm.executeUpdate();
                                                        cardLayout4use.show(cardLayout, "7");
                                                        JOptionPane.showMessageDialog(null, "Success!!");
                                                }

                                                newDevId.setText("");
                                                psstm.close();
                                                myResult1.close();
                                                conn.close();
                                        }
                                        catch(Exception ex){
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                }
                        }
                });
                addDev.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "12"); }
                });

        }


        @Override
        public void actionPerformed(ActionEvent e) {

        }
}

