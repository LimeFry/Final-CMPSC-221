import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;

import java.sql.*;
import java.math.*;
import java.util.Locale;
// for the border
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class Final_Project extends JFrame implements ActionListener{
        static JMenuBar mb;
        static JFrame f;
        private static JPanel cardLayout;
        private static CardLayout cardLayout4use = new CardLayout();

        // for the user
        private static String user = null;
        private static int developer = 0;
        private static int add_edit = 0;
        private static String admin = null;

        // for database connection, commonalities
//        private static String mainDatabase = "MAIN_DATABASE";
//        private static String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
//        private static Statement stm;
//        private static Connection conn = null;
//        private static PreparedStatement psstm;

        // font
        private static Font labelFont = new Font("Anton", Font.PLAIN, 18);
        private static Font labelFont2 = new Font("Anton", Font.ITALIC, 18);
        private static Font biggerFont = labelFont.deriveFont(20f);
        private static Font massiveFont = biggerFont.deriveFont(50f);
        // color
        private static Color customerColor = new Color(226, 135, 54);
        private static Color adminColor = new Color(78, 87, 123);
        private static Color devColor = new Color(146, 213,123);

        //--------CREATING ALL THE DATABASES----------------------------------------------------------------------------
        public static void createDatabase() {
                // common variables
                String mainDatabase = "MAIN_DATABASE";
                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                Statement stm;
                Connection conn = null;
                PreparedStatement psstm;
                ResultSet myResult1, myResult2, myResult3, myResult4;
                String createCust = "CREATE TABLE CUST (ID INT, NAME VARCHAR(30), TAGS VARCHAR(255))"; // MAYBE ADD STUFF FROM WHITEBORAD -> REMOVE BEFORE SUBMISSION
                String createDev = "CREATE TABLE DEV (DEVID INT, OWNEDGAMES VARCHAR(255))";
                String createBackend = "CREATE TABLE BACKEND (BACKENDNAME VARCHAR(30))";
                String createGame = "CREATE TABLE GAME (GAMENAME VARCHAR(30), GAMESCORE DOUBLE, GAMERATING VARCHAR(30), GAMEPLAYTIME INT, GAMEGB INT, GAMEPRICE DOUBLE, GAMETAGS VARCHAR(255), GAMEUSERSCORE VARCHAR(255))";

                try {
                        conn = DriverManager.getConnection(connectionURL);
                        stm = conn.createStatement();
                        myResult1 = conn.getMetaData().getTables(null, null, "CUST", null);
                        myResult2 = conn.getMetaData().getTables(null, null, "DEV", null);
                        myResult3 = conn.getMetaData().getTables(null, null, "BACKEND", null);
                        myResult4 = conn.getMetaData().getTables(null, null, "GAME", null);

                        if (myResult1.next() || myResult2.next() || myResult3.next() || myResult4.next()) {
                                System.out.println("Tables already exist");
                        }
                        else {
                                stm.execute(createCust);
                                stm.execute(createDev);
                                stm.execute(createBackend);
                                stm.execute(createGame);
                                System.out.println("Tables are created");
                        }
                        conn.close();
                        stm.close();
                        myResult1.close();
                        myResult2.close();
                        myResult3.close();
                        myResult4.close();
                } catch (Throwable ex) {
                        System.out.println("... exception thrown:");
                        ex.printStackTrace(System.out);
                }

        }

        //ADD STUFF TO DATABASES----------------------------------------------------------------------------------------

        public static void addToDatabase(){
                String mainDatabase = "MAIN_DATABASE";
                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                Statement stm;
                Connection conn = null;
                PreparedStatement psstm;
                ResultSet myResult, myResult1;
                try {
                        conn = DriverManager.getConnection(connectionURL);
                        stm = conn.createStatement();
                        myResult = conn.getMetaData().getTables(null, null, "CUST", null);
                        myResult1 = stm.executeQuery("select ID from CUST");
                        if (!myResult.next())
                                System.out.println("Table does not exist");
                        else if(myResult1.next()) {
                                System.out.println("Table already populated");
                        }
                        else {
                                psstm = conn.prepareStatement("INSERT into CUST (ID, NAME, TAGS) VALUES (?,?,?)");
                                psstm.setInt(1, 1234);
                                psstm.setString(2, "Jimmy");
                                psstm.setString(3, "open world,adventure,first person shooter,online");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into CUST (ID, NAME, TAGS) VALUES (?,?,?)");
                                psstm.setInt(1, 7890);
                                psstm.setString(2, "Chucky");
                                psstm.setString(3, "open world,adventure,sandbox,tabletop,calming,gambling");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into DEV (DEVID, OWNEDGAMES) VALUES (?,?)");
                                psstm.setInt(1, 4321);
                                psstm.setString(2, "Minecraft,Call Of Duty,Poker,GTAVI");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into BACKEND (BACKENDNAME) VALUES (?)");
                                psstm.setString(1, "Glen");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS, GAMEUSERSCORE) VALUES (?,?,?,?,?,?,?,?)");
                                psstm.setString(1, "Minecraft");
                                psstm.setDouble(2, 4.5);
                                psstm.setString(3, "E");
                                psstm.setInt(4, 120);
                                psstm.setInt(5, 4);
                                psstm.setInt(6, 30);
                                psstm.setString(7, "open world,adventure,sandbox,survival,online");
                                psstm.setString(8, "4,3,5,5,5,4,3,2,5");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS, GAMEUSERSCORE) VALUES (?,?,?,?,?,?,?,?)");
                                psstm.setString(1, "Call Of Duty");
                                psstm.setDouble(2, 3.0);
                                psstm.setString(3, "PG-13");
                                psstm.setInt(4, 150);
                                psstm.setInt(5, 120);
                                psstm.setInt(6, 60);
                                psstm.setString(7, "first person shooter,adventure,tactical shooter,online");
                                psstm.setString(8, "4,5,5,5,5,4,3,5,5");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS, GAMEUSERSCORE) VALUES (?,?,?,?,?,?,?,?)");
                                psstm.setString(1, "Poker");
                                psstm.setDouble(2, 3.0);
                                psstm.setString(3, "E");
                                psstm.setInt(4, 300);
                                psstm.setInt(5, 5);
                                psstm.setInt(6, 10);
                                psstm.setString(7, "casual,calming,tabletop,gambling");
                                psstm.setString(8, "4,2,3,3,5,4,3,5,5");
                                psstm.executeUpdate();
                                psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS, GAMEUSERSCORE) VALUES (?,?,?,?,?,?,?,?)");
                                psstm.setString(1, "GTAVI");
                                psstm.setDouble(2, 5.0);
                                psstm.setString(3, "M");
                                psstm.setInt(4, 720);
                                psstm.setInt(5, 300);
                                psstm.setInt(6, 60);
                                psstm.setString(7, "story,third person shooter,online,adventure,open world");
                                psstm.setString(8, "1,4,2,5,5,4,3,5,5");
                                psstm.executeUpdate();
                                stm.close();
                                psstm.close();
                                myResult.close();
                        }
                } catch (Exception e) {
                        System.out.println("...exception thrown:");
                        e.printStackTrace();
                }
        }
        

        // for the 'who are you' panel
        private static JPanel signInPanel;
        private static JLabel signInInfo, imageLabel;
        private static JButton customer, dev, backendUser;



        //----------FOR CUSTOMER PURPOSES ONLY--------------------------------------------------------------------------


        // for the customer login panel
        private static JPanel customerLogin;
        private static JLabel login_1;
        private static JTextField id1;
        private static JButton login1;
        private static JButton back1;

        // for the customer main panel
        private static JPanel customerMainScreen;
        private static JLabel tags, games;
        private static JTextField tagsEnter;
        private static JButton addTags, rent, buy, info, logout, removeTag;
        private static DefaultListModel<String> tagModel = new DefaultListModel<>();
        private static DefaultListModel<String> gameModel = new DefaultListModel<>();
        private static DefaultComboBoxModel<String> cbRemoveTags = new DefaultComboBoxModel<>();

        // for the customer info panel
        private static JPanel customerInfoPanel;
        private static JLabel infoTitle, custName, custScore, custRating, custPlaytime, custSize, custPrice, custTags, custReviews;
        private static JTextField disName, disScore, disRating, disPlaytime, disSize, disPrice;
        private static DefaultListModel<String> gameTagsInfo = new DefaultListModel<>();
        private static DefaultListModel<String> gameReview = new DefaultListModel<>();
        private static JButton backToMain;
        // need a list to display the tags of course

        //Customer Buy/Rent Page
        private static JPanel transactionPanel;
        private static JButton completeTransaction, cancel;
        private static JLabel transactionTitle, cardNumTitle, gameSelectionTitle, priceOfGameTitle;
        private static JTextField cardEntry, gameSelection, priceOfGame;


        //----------FOR DEVELOPER PURPOSES ONLY-----------------------------------------------------------------------------


        // for the dev login panel
        private static JPanel devLogin;
        private static JLabel login_3;
        private static JTextField id3;
        private static JButton login3;
        private static JButton back3;

        // for the dev main panel
        private static JPanel devMain;
        private static JLabel devMainLabel;
        private static DefaultListModel<String> ownedGamesModel = new DefaultListModel<>();
        private static JButton editGameButton, addGameButton, deleteGameButton, devLogout;

        // dev add/edit
        private static JPanel devGamePanel;
        private static JLabel devInfoTitle, devName, devScore, devRating, devPlaytime, devSize, devPrice, devTags, devReviews;
        private static JTextField devDisName, devDisScore, devDisRating, devDisPlaytime, devDisSize, devDisPrice,devEditAddTag;
        private static DefaultComboBoxModel<String> cbEditTagsModel = new DefaultComboBoxModel<>();
        private static DefaultListModel<String> devGameTags = new DefaultListModel<>();
        private static DefaultListModel<String> devGameReviews = new DefaultListModel<>();
        private static JButton devBackToMain, completeChanges, devAddToTags, devRemoveToTags;


        //----------FOR ADMIN PURPOSES ONLY-----------------------------------------------------------------------------


        // for the backend login panel
        private static JPanel backendLogin;
        private static JLabel login_2;
        private static JTextField id2;
        private static JButton login2;
        private static JButton back2;

        // for the backend main panel
        private static JPanel backendMainScreen;
        private static JLabel backendTitle;
        private static JTextField enterUser;
        private static JButton addUser, deleteUser, backendLogout, devPage, custPage, addDev;

        // for Add user panel
        private static JPanel addUserAdmin;
        private static JLabel enterName, enterId, addTitle;
        private static JTextField newUserId, newUserName;
        private static JButton complete, backToAdminActions;

        // for Dev user panel
        private static JPanel addDevAdmin;
        private static JLabel enterDevId, addTitleDev;
        private static JTextField newDevId;
        private static JButton devComplete, backToAdminActionsDev;


        //MAIN FUNCTION


        public static void main(String[] args)
        {
                f = new JFrame("Video Game Browser");
                f.setSize(1000,1000);
                Final_Project browser = new Final_Project();
                createDatabase();
                addToDatabase();
                browser.create(f);
                f.setVisible(true);

        }


        //Main Frame Creation


        public static void create (JFrame f)
        {
                Final_Project mylist = new Final_Project();
                cardLayout = new JPanel();
                cardLayout.setLayout(cardLayout4use);
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.anchor = GridBagConstraints.FIRST_LINE_START;
                gbc.weightx = 0.5;
                gbc.weighty = 0.5;
                gbc.gridwidth = 1;
                gbc.ipadx = 10;
                gbc.ipady = 20;
                gbc.fill = GridBagConstraints.BOTH;
                gbc.insets = new Insets(10,10,10,10);


                // for the Who are you panel
                signInPanel = new JPanel();
                signInInfo = new JLabel("Select Sign in Type");
                signInPanel.setBackground(Color.LIGHT_GRAY);
                signInInfo.setFont(massiveFont);

                customer = new JButton("Customer");
                customer.setBackground(customerColor);
                customer.setOpaque(true);
                customer.setBorder(new LineBorder(Color.darkGray, 4));
                customer.setContentAreaFilled(true);
                customer.setFocusPainted(false);

                backendUser = new JButton("Backend User");
                backendUser.setBackground(adminColor);
                backendUser.setOpaque(true);
                backendUser.setBorder(new LineBorder(Color.darkGray, 4));
                backendUser.setContentAreaFilled(true);
                backendUser.setFocusPainted(false);

                ImageIcon gameImage = new ImageIcon("src/resources/images/main.jpg");
                ImageIcon devImage = new ImageIcon("src/resources/images/dev.jpg");
                Image scaledImage = devImage.getImage().getScaledInstance(150, 75, Image.SCALE_SMOOTH);
                ImageIcon scaledIcon = new ImageIcon(scaledImage);
                imageLabel = new JLabel(gameImage);

                dev = new JButton("Developer", scaledIcon);
                dev.setBackground(devColor);
                dev.setOpaque(true);
                dev.setBorder(new LineBorder(Color.darkGray, 4));
                dev.setContentAreaFilled(true);
                dev.setFocusPainted(false);



                Border panelBorder11 = BorderFactory.createTitledBorder("Account type selection");
                signInPanel.setBorder(panelBorder11);
                signInPanel.setLayout(null);
                customer.setFont(biggerFont);
                backendUser.setFont(biggerFont);
                dev.setFont(biggerFont);

                BufferedImage image;
                //image = ImageIO.read(create.class.getResource("/resources/icon.gif"));

                signInInfo.setBounds(275,100,500,200);
                customer.setBounds(25, 400, 300,200);
                dev.setBounds(350, 400, 300,200);
                backendUser.setBounds(675, 400, 300,200);
                imageLabel.setBounds(350, 500, 400, 400);
                signInPanel.add(signInInfo);
                signInPanel.add(customer);
                signInPanel.add(dev);
                signInPanel.add(backendUser);


                //----------FOR CUSTOMER PURPOSES ONLY-----------------------------------------------------------------------------


                // for the customer login panel
                customerLogin = new JPanel();
                customerLogin.setLayout(new GridBagLayout());
                customerLogin.setBackground(customerColor);
                customerLogin.setBorder(panelBorder11);
                customerLogin.setLayout(null);

                login_1 = new JLabel("What is your id?");
                login_1.setBackground(Color.LIGHT_GRAY);
                login_1.setFont(massiveFont);

                login1 = new JButton("Log In");
                login1.setOpaque(true);
                login1.setBorder(new LineBorder(Color.darkGray, 4));
                login1.setContentAreaFilled(true);
                login1.setFocusPainted(false);
                login1.setFont(biggerFont);

                back1 = new JButton("Back");
                back1.setOpaque(true);
                back1.setBorder(new LineBorder(Color.darkGray, 4));
                back1.setContentAreaFilled(true);
                back1.setFocusPainted(false);
                back1.setFont(biggerFont);

                id1 = new JTextField(10);
                id1.setOpaque(true);
                id1.setEditable(true);
                id1.setFont(biggerFont);
                id1.setBorder(new LineBorder(Color.darkGray, 4));

                Border panelBorder = BorderFactory.createTitledBorder("Customer Login");

                login_1.setBounds(100, 150, 500,200);
                id1.setBounds(100,300,400,100);
                back1.setBounds(100,425,400,100);
                login1.setBounds(550, 300, 400, 100);
                customerLogin.add(login_1);
                customerLogin.add(login1);
                customerLogin.add(id1);
                customerLogin.add(back1);

                // for the customer main/third page
                customerMainScreen = new JPanel();
                customerMainScreen.setLayout(null);
                customerMainScreen.setBackground(customerColor);

                tags = new JLabel("Tags");
                tags.setBackground(Color.LIGHT_GRAY);
                tags.setFont(biggerFont);

                games = new JLabel("Games");
                games.setBackground(Color.LIGHT_GRAY);
                games.setFont(biggerFont);

                JList<String> tagsList = new JList<>(tagModel);
                tagsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                tagsList.setVisibleRowCount(10);
                tagsList.setOpaque(true);
                tagsList.setBorder(new LineBorder(Color.darkGray, 4));
                tagsList.setFont(biggerFont);
                tagsList.setToolTipText("These are your Tags");
                tagsList.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(255, 218, 170)); // Set background color when selected
                                        label.setForeground(new Color(125, 75, 0)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }
                                return label;
                        }
                });

                JList<String> gamesList = new JList<>(gameModel);
                gamesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                gamesList.setVisibleRowCount(2);
                gamesList.setOpaque(true);
                gamesList.setBorder(new LineBorder(Color.darkGray, 4));
                gamesList.setFont(biggerFont);
                gamesList.setToolTipText("These are the games that your Tags recommend");
                gamesList.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(255, 218, 170)); // Set background color when selected
                                        label.setForeground(new Color(125, 75, 0)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }

                                return label;
                        }
                });

                JComboBox<String> tagsToRemove = new JComboBox<>(cbRemoveTags);
                gamesList.setBorder(new LineBorder(Color.darkGray, 4));
                tagsToRemove.setFont(biggerFont);
                tagsToRemove.setToolTipText("Select a Tag to be removed here");

                removeTag = new JButton("Remove");
                removeTag.setToolTipText("Click here to remove selected Tag");
                removeTag.setOpaque(true);
                removeTag.setBorder(new LineBorder(Color.darkGray, 4));
                removeTag.setContentAreaFilled(true);
                removeTag.setFocusPainted(false);
                removeTag.setFont(biggerFont);

                tagsEnter = new JTextField(10);
                tagsEnter.setOpaque(true);
                tagsEnter.setBorder(new LineBorder(Color.darkGray, 4));
                tagsEnter.setFont(biggerFont);
                tagsEnter.setToolTipText("Enter your new Tag here");

                addTags = new JButton("Add");
                addTags.setOpaque(true);
                addTags.setBorder(new LineBorder(Color.darkGray, 4));
                addTags.setContentAreaFilled(true);
                addTags.setFocusPainted(false);
                addTags.setFont(biggerFont);
                addTags.setToolTipText("Add the Tag into your personal Tags List");

                rent = new JButton("Rent");
                rent.setOpaque(true);
                rent.setBorder(new LineBorder(Color.darkGray, 4));
                rent.setContentAreaFilled(true);
                rent.setFocusPainted(false);
                rent.setFont(biggerFont);
                rent.setToolTipText("Rent the selected game?");

                buy = new JButton("Buy");
                buy.setOpaque(true);
                buy.setBorder(new LineBorder(Color.darkGray, 4));
                buy.setContentAreaFilled(true);
                buy.setFocusPainted(false);
                buy.setFont(biggerFont);
                buy.setToolTipText("Buy the selected game?");

                info = new JButton("Info");
                info.setOpaque(true);
                info.setBorder(new LineBorder(Color.darkGray, 4));
                info.setContentAreaFilled(true);
                info.setFocusPainted(false);
                info.setFont(biggerFont);
                info.setToolTipText("Gives information on the selected game");

                logout = new JButton("Logout");
                logout.setOpaque(true);
                logout.setBorder(new LineBorder(Color.darkGray, 4));
                logout.setContentAreaFilled(true);
                logout.setFocusPainted(false);
                logout.setFont(biggerFont);
                logout.setToolTipText("Logout");

                Border panelBorder2 = BorderFactory.createTitledBorder("Customer Home Page");
                customerMainScreen.setBorder(panelBorder2);

                tags.setBounds(50,45,250,200);
                games.setBounds(645,45,250,200);
                tagsList.setBounds(50,160,300,300);
                gamesList.setBounds(645,160,300,300);
                tagsEnter.setBounds(10,484,200,75);
                addTags.setBounds(215,470,200,100);
                tagsToRemove.setBounds(10,575,200,100);
                removeTag.setBounds(215,575,200,100);
                rent.setBounds(585,470,200,100);
                buy.setBounds(790,470,200,100);
                info.setBounds(688,575,200,100);
                logout.setBounds(400,750,200,100);

                customerMainScreen.add(tags);
                customerMainScreen.add(games);
                customerMainScreen.add(tagsList);
                customerMainScreen.add(gamesList);
                customerMainScreen.add(tagsEnter);
                customerMainScreen.add(addTags);
                customerMainScreen.add(tagsToRemove);
                customerMainScreen.add(removeTag);
                customerMainScreen.add(rent);
                customerMainScreen.add(buy);
                customerMainScreen.add(info);
                customerMainScreen.add(logout);

                // for the customer info screen
                customerInfoPanel = new JPanel();
                customerInfoPanel.setBackground(customerColor);
                customerInfoPanel.setLayout(null);

                infoTitle = new JLabel("INFO: ");
                infoTitle.setBackground(Color.LIGHT_GRAY);
                infoTitle.setFont(biggerFont);

                custName = new JLabel("Name: ");
                custName.setBackground(Color.LIGHT_GRAY);
                custName.setFont(biggerFont);

                custScore = new JLabel("Score: ");
                custScore.setBackground(Color.LIGHT_GRAY);
                custScore.setFont(biggerFont);

                custRating = new JLabel("Rating: ");
                custRating.setBackground(Color.LIGHT_GRAY);
                custRating.setFont(biggerFont);

                custPlaytime = new JLabel("Playtime: ");
                custPlaytime.setBackground(Color.LIGHT_GRAY);
                custPlaytime.setFont(biggerFont);


                custSize = new JLabel("Size: ");
                custSize.setBackground(Color.LIGHT_GRAY);
                custSize.setFont(biggerFont);


                custPrice = new JLabel("Price: ");
                custPrice.setBackground(Color.LIGHT_GRAY);
                custPrice.setFont(biggerFont);


                custTags = new JLabel("Tags: ");
                custTags.setBackground(Color.LIGHT_GRAY);
                custTags.setFont(biggerFont);
                custTags.setToolTipText("The tags for this game");

                custReviews = new JLabel("Reviews: ");
                custReviews.setBackground(Color.LIGHT_GRAY);
                custReviews.setFont(biggerFont);
                custReviews.setToolTipText("the reviews for this game");

                disName = new JTextField(10);
                disName.setOpaque(true);
                disName.setEditable(false);
                disName.setFont(biggerFont);
                disName.setBorder(new LineBorder(Color.darkGray, 4));
                custName.setToolTipText("The name of the game");

                disScore = new JTextField(10);
                disScore.setOpaque(true);
                disScore.setEditable(false);
                disScore.setFont(biggerFont);
                disScore.setBorder(new LineBorder(Color.darkGray, 4));
                disScore.setToolTipText("the average score from users for this game");

                disRating = new JTextField(10);
                disRating.setOpaque(true);
                disRating.setEditable(false);
                disRating.setFont(biggerFont);
                disRating.setBorder(new LineBorder(Color.darkGray, 4));
                disRating.setToolTipText("The maturity rating for this game");

                disPlaytime = new JTextField(10);
                disPlaytime.setOpaque(true);
                disPlaytime.setEditable(false);
                disPlaytime.setFont(biggerFont);
                disPlaytime.setBorder(new LineBorder(Color.darkGray, 4));
                disPlaytime.setToolTipText("The average playtime for this game");

                disSize = new JTextField(10);
                disSize.setOpaque(true);
                disSize.setEditable(false);
                disSize.setFont(biggerFont);
                disSize.setBorder(new LineBorder(Color.darkGray, 4));
                disSize.setToolTipText("The size of this game");

                disPrice = new JTextField(10);
                disPrice.setOpaque(true);
                disPrice.setEditable(false);
                disPrice.setFont(biggerFont);
                disPrice.setBorder(new LineBorder(Color.darkGray, 4));
                disPrice.setToolTipText("The price of this game in Dollars");

                backToMain = new JButton("Back");
                backToMain.setOpaque(true);
                backToMain.setBorder(new LineBorder(Color.darkGray, 4));
                backToMain.setContentAreaFilled(true);
                backToMain.setFocusPainted(false);
                backToMain.setFont(biggerFont);
                backToMain.setToolTipText("Rent the selected game?");

                JList<String> disReviews = new JList<>(gameReview);
                disReviews.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                disReviews.setVisibleRowCount(2);
                disReviews.setOpaque(true);
                disReviews.setBorder(new LineBorder(Color.darkGray, 4));
                disReviews.setFont(labelFont);
                disReviews.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(255, 218, 170)); // Set background color when selected
                                        label.setForeground(new Color(125, 75, 0)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }

                                return label;
                        }
                });

                JList<String> tagsDisplay = new JList<>(gameTagsInfo);
                tagsDisplay.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                tagsDisplay.setVisibleRowCount(2);
                tagsDisplay.setOpaque(true);
                tagsDisplay.setBorder(new LineBorder(Color.darkGray, 4));
                tagsDisplay.setFont(biggerFont);
                tagsDisplay.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(255, 218, 170)); // Set background color when selected
                                        label.setForeground(new Color(125, 75, 0)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }

                                return label;
                        }
                });

                infoTitle.setBounds(50,50,200,100);
                custName.setBounds(50, 105,200,100);
                custScore.setBounds(50,260,200,100);
                custRating.setBounds(50,415,200,100);
                custPlaytime.setBounds(50,570,200,100);
                custSize.setBounds(460,105,200,100);
                custPrice.setBounds(460,260,200,100);
                custReviews.setBounds(460,415,200,100);
                custTags.setBounds(700,415,200,100);
                disName.setBounds(50,170,200,100);
                disScore.setBounds(50,325,200,100);
                disRating.setBounds(50,480,200,100);
                disPlaytime.setBounds(50,635,200,100);
                disSize.setBounds(460,170,200,100);
                disPrice.setBounds(460,325,200,100);
                disReviews.setBounds(460,480,200,255);
                tagsDisplay.setBounds(700,480,200,255);
                backToMain.setBounds(400,800,200,100);

                customerInfoPanel.add(infoTitle);
                customerInfoPanel.add(custName);
                customerInfoPanel.add(custScore);
                customerInfoPanel.add(custRating);
                customerInfoPanel.add(custPlaytime);
                customerInfoPanel.add(custSize);
                customerInfoPanel.add(custPrice);
                customerInfoPanel.add(custReviews);
                customerInfoPanel.add(custTags);
                customerInfoPanel.add(disName);
                customerInfoPanel.add(disScore);
                customerInfoPanel.add(disRating);
                customerInfoPanel.add(disPlaytime);
                customerInfoPanel.add(disSize);
                customerInfoPanel.add(disPrice);
                customerInfoPanel.add(disReviews);
                customerInfoPanel.add(tagsDisplay);
                customerInfoPanel.add(backToMain);

                // Customer Transaction Panel
                transactionPanel = new JPanel();
                transactionPanel.setBackground(customerColor);
                transactionPanel.setLayout(null);

                completeTransaction = new JButton("Continue");
                completeTransaction.setOpaque(true);
                completeTransaction.setBorder(new LineBorder(Color.darkGray, 4));
                completeTransaction.setContentAreaFilled(true);
                completeTransaction.setFocusPainted(false);
                completeTransaction.setFont(biggerFont);
                completeTransaction.setToolTipText("Rent the selected game?");

                cancel = new JButton("Cancel");
                cancel.setOpaque(true);
                cancel.setContentAreaFilled(true);
                cancel.setBorder(new LineBorder(Color.darkGray, 4));
                cancel.setFocusPainted(false);
                cancel.setFont(biggerFont);
                cancel.setToolTipText("Cancel Transaction");

                transactionTitle = new JLabel("Transaction Page");
                transactionTitle.setBackground(Color.LIGHT_GRAY);
                transactionTitle.setFont(massiveFont);

                cardNumTitle = new JLabel("Input Card Number");
                cardNumTitle.setBackground(Color.LIGHT_GRAY);
                cardNumTitle.setFont(biggerFont);

                gameSelection = new JTextField(10);
                gameSelection.setOpaque(true);
                gameSelection.setFont(biggerFont);
                gameSelection.setEditable(false);
                gameSelection.setBorder(new LineBorder(Color.darkGray, 4));

                gameSelectionTitle = new JLabel("Selected Game");
                gameSelectionTitle.setBackground(Color.LIGHT_GRAY);
                gameSelectionTitle.setFont(biggerFont);

                cardEntry = new JTextField();
                cardEntry.setOpaque(true);
                cardEntry.setEditable(false);
                cardEntry.setFont(biggerFont);
                cardEntry.setBorder(new LineBorder(Color.darkGray, 4));

                priceOfGame = new JTextField();
                priceOfGame.setOpaque(true);
                priceOfGame.setEditable(false);
                priceOfGame.setFont(biggerFont);
                priceOfGame.setBorder(new LineBorder(Color.darkGray, 4));

                Border panelBorder4 = BorderFactory.createTitledBorder("Customer Transaction");
                transactionPanel.setBorder(panelBorder4);
                priceOfGameTitle = new JLabel("Price: ");
                priceOfGameTitle.setFont(biggerFont);

                completeTransaction.setBounds(290,700,200,100);
                cancel.setBounds(510,700,200,100);
                transactionTitle.setBounds(300,25,800,100);
                gameSelectionTitle.setBounds(200,205,200,100);
                gameSelection.setBounds(500,205,300,100);
                priceOfGame.setBounds(500,315,300,100);
                priceOfGameTitle.setBounds(200,315,200,100);
                cardNumTitle.setBounds(400,400,200,100);
                cardEntry.setBounds(300,515,400,100);

                transactionPanel.add(completeTransaction);
                transactionPanel.add(cancel);
                transactionPanel.add(transactionTitle);
                transactionPanel.add(gameSelectionTitle);
                transactionPanel.add(gameSelection);
                transactionPanel.add(priceOfGame);
                transactionPanel.add(priceOfGameTitle);
                transactionPanel.add(cardNumTitle);
                transactionPanel.add(cardEntry);


                //----------FOR DEVELOPERS PURPOSES ONLY-----------------------------------------------------------------------------


                // for the dev login panel
                devLogin = new JPanel();
                devLogin.setBackground(devColor);
                devLogin.setLayout(null);

                login_2 = new JLabel("What is your id?");
                login_2.setBackground(Color.LIGHT_GRAY);
                login_2.setFont(massiveFont);

                login2 = new JButton("Log In");
                login2.setOpaque(true);
                login2.setContentAreaFilled(true);
                login2.setBorder(new LineBorder(Color.darkGray, 4));
                login2.setFocusPainted(false);
                login2.setFont(biggerFont);

                id2 = new JTextField(10);
                id2.setOpaque(true);
                id2.setEditable(true);
                id2.setFont(biggerFont);
                id2.setBorder(new LineBorder(Color.darkGray, 4));

                back2 = new JButton("Back");
                back2.setOpaque(true);
                back2.setContentAreaFilled(true);
                back2.setBorder(new LineBorder(Color.darkGray, 4));
                back2.setFocusPainted(false);
                back2.setFont(biggerFont);

                Border panelBorder5 = BorderFactory.createTitledBorder("Developer Login");
                devLogin.setBorder(panelBorder5);

                login_2.setBounds(100, 150, 500,200);
                id2.setBounds(100,300,400,100);
                back2.setBounds(100,425,400,100);
                login2.setBounds(550, 300, 400, 100);
                devLogin.add(login_2);
                devLogin.add(login2);
                devLogin.add(id2);
                devLogin.add(back2);


                // for the dev main/third page
                devMain = new JPanel();
                devMain.setBackground(devColor);
                devMain.setLayout(null);
                JList<String> ownedGames = new JList<>(ownedGamesModel);
                ownedGames.setOpaque(true);
                ownedGames.setBorder(new LineBorder(Color.darkGray, 4));
                ownedGames.setFont(biggerFont);
                ownedGames.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(85, 255, 23));// Set background color when selected
                                        label.setForeground(new Color(53, 115, 30)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }

                                return label;
                        }
                });

                // Set fixed cell height for bigger rows
                ownedGames.setFixedCellHeight(50);

                editGameButton = new JButton("Edit Game");
                editGameButton.setOpaque(true);
                editGameButton.setBorder(new LineBorder(Color.darkGray, 4));
                editGameButton.setContentAreaFilled(true);
                editGameButton.setFocusPainted(false);
                editGameButton.setFont(biggerFont);
                editGameButton.setToolTipText("edit the selected game");

                addGameButton = new JButton("Add Game");
                addGameButton.setOpaque(true);
                addGameButton.setBorder(new LineBorder(Color.darkGray, 4));
                addGameButton.setContentAreaFilled(true);
                addGameButton.setFocusPainted(false);
                addGameButton.setFont(biggerFont);
                addGameButton.setToolTipText("create a new game or add a game to the library");

                deleteGameButton = new JButton("Delete Game");
                deleteGameButton.setOpaque(true);
                deleteGameButton.setBorder(new LineBorder(Color.darkGray, 4));
                deleteGameButton.setContentAreaFilled(true);
                deleteGameButton.setFocusPainted(false);
                deleteGameButton.setFont(biggerFont);
                deleteGameButton.setToolTipText("delete the selected game");

                devLogout = new JButton("Logout");
                devLogout.setOpaque(true);
                devLogout.setBorder(new LineBorder(Color.darkGray, 4));
                devLogout.setContentAreaFilled(true);
                devLogout.setFocusPainted(false);
                devLogout.setFont(biggerFont);

                devMainLabel = new JLabel("List Of Owned Games");
                devMainLabel.setBackground(Color.LIGHT_GRAY);
                devMainLabel.setFont(biggerFont);

                Border panelBorder6 = BorderFactory.createTitledBorder("Developer Home Page");
                devMain.setBorder(panelBorder6);

                devMainLabel.setBounds(50,45,300,50);
                editGameButton.setBounds(675, 100, 275, 150);
                addGameButton.setBounds(675, 255,275,150);
                deleteGameButton.setBounds(675,410,275,150);
                devLogout.setBounds(675,565,275,150);
                ownedGames.setBounds(50,100,600,620);
                devMain.add(devMainLabel);
                devMain.add(ownedGames);
                devMain.add(editGameButton);
                devMain.add(addGameButton);
                devMain.add(deleteGameButton);
                devMain.add(devLogout);


                // Dev Add/Edit game Panel
                devGamePanel = new JPanel();
                devGamePanel.setBackground(devColor);
                devGamePanel.setLayout(null);

                devInfoTitle = new JLabel("INFO: ");
                devInfoTitle.setBackground(Color.LIGHT_GRAY);
                devInfoTitle.setFont(massiveFont);

                devName = new JLabel("Name: ");
                devName.setBackground(Color.LIGHT_GRAY);
                devName.setFont(biggerFont);

                devScore = new JLabel("Score: ");
                devScore.setBackground(Color.LIGHT_GRAY);
                devScore.setFont(biggerFont);

                devRating = new JLabel("Rating: ");
                devRating.setBackground(Color.LIGHT_GRAY);
                devRating.setFont(biggerFont);

                devPlaytime = new JLabel("Playtime: ");
                devPlaytime.setBackground(Color.LIGHT_GRAY);
                devPlaytime.setFont(biggerFont);

                devSize = new JLabel("Size: ");
                devSize.setBackground(Color.LIGHT_GRAY);
                devSize.setFont(biggerFont);

                devPrice = new JLabel("Price: ");
                devPrice.setBackground(Color.LIGHT_GRAY);
                devPrice.setFont(biggerFont);

                devTags = new JLabel("Tags: ");
                devTags.setBackground(Color.LIGHT_GRAY);
                devTags.setFont(biggerFont);

                devReviews = new JLabel("Individual User Scores: ");
                devReviews.setBackground(Color.LIGHT_GRAY);
                devReviews.setFont(labelFont);

                devDisName = new JTextField(10);
                devDisName.setOpaque(true);
                devDisName.setEditable(true);
                devDisName.setFont(biggerFont);
                devDisName.setBorder(new LineBorder(Color.darkGray, 4));

                devDisScore = new JTextField(10);
                devDisScore.setOpaque(true);
                devDisScore.setEditable(true);
                devDisScore.setFont(biggerFont);
                devDisScore.setBorder(new LineBorder(Color.darkGray, 4));

                devDisRating = new JTextField(10);
                devDisRating.setOpaque(true);
                devDisRating.setEditable(true);
                devDisRating.setFont(biggerFont);
                devDisRating.setBorder(new LineBorder(Color.darkGray, 4));

                devDisPlaytime = new JTextField(10);
                devDisPlaytime.setOpaque(true);
                devDisPlaytime.setEditable(true);
                devDisPlaytime.setFont(biggerFont);
                devDisPlaytime.setBorder(new LineBorder(Color.darkGray, 4));

                devDisSize = new JTextField(10);
                devDisSize.setOpaque(true);
                devDisSize.setEditable(true);
                devDisSize.setFont(biggerFont);
                devDisSize.setBorder(new LineBorder(Color.darkGray, 4));

                devDisPrice = new JTextField(10);
                devDisPrice.setOpaque(true);
                devDisPrice.setEditable(true);
                devDisPrice.setFont(biggerFont);
                devDisPrice.setBorder(new LineBorder(Color.darkGray, 4));

                devEditAddTag = new JTextField(10);
                devEditAddTag.setOpaque(true);
                devEditAddTag.setEditable(true);
                devEditAddTag.setFont(biggerFont);
                devEditAddTag.setBorder(new LineBorder(Color.darkGray, 4));

                devBackToMain = new JButton("Back");
                devBackToMain.setOpaque(true);
                devBackToMain.setContentAreaFilled(true);
                devBackToMain.setBorder(new LineBorder(Color.darkGray, 4));
                devBackToMain.setFocusPainted(false);
                devBackToMain.setFont(biggerFont);

                completeChanges = new JButton("Complete");
                completeChanges.setOpaque(true);
                completeChanges.setContentAreaFilled(true);
                completeChanges.setBorder(new LineBorder(Color.darkGray, 4));
                completeChanges.setFocusPainted(false);
                completeChanges.setFont(biggerFont);
                completeChanges.setToolTipText("Complete changes?");

                devAddToTags = new JButton("Add");
                devAddToTags.setOpaque(true);
                devAddToTags.setContentAreaFilled(true);
                devAddToTags.setBorder(new LineBorder(Color.darkGray, 4));
                devAddToTags.setFocusPainted(false);
                devAddToTags.setFont(biggerFont);
                devAddToTags.setToolTipText("Add to the Tags List");

                devRemoveToTags = new JButton("Remove");
                devRemoveToTags.setOpaque(true);
                devRemoveToTags.setContentAreaFilled(true);
                devRemoveToTags.setBorder(new LineBorder(Color.darkGray, 4));
                devRemoveToTags.setFocusPainted(false);
                devRemoveToTags.setFont(biggerFont);
                devRemoveToTags.setToolTipText("Remove from the Tags Lists");

                JList<String> devTagsDisplay = new JList<>(devGameTags);
                devTagsDisplay.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                devTagsDisplay.setVisibleRowCount(2);
                devTagsDisplay.setOpaque(true);
                devTagsDisplay.setBorder(new LineBorder(Color.darkGray, 4));
                devTagsDisplay.setFont(biggerFont);
                devTagsDisplay.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(85, 255, 23));// Set background color when selected
                                        label.setForeground(new Color(53, 115, 30)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }

                                return label;
                        }
                });
                JList<String> devReviewDisplay = new JList<>(devGameReviews);
                devReviewDisplay.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                devReviewDisplay.setVisibleRowCount(2);
                devReviewDisplay.setOpaque(true);
                devReviewDisplay.setBorder(new LineBorder(Color.darkGray, 4));
                devReviewDisplay.setFont(biggerFont);
                devReviewDisplay.setCellRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(
                                JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                                // Align the text to the left and center vertically
                                label.setHorizontalAlignment(SwingConstants.CENTER);  // Left-aligned text
                                label.setVerticalAlignment(SwingConstants.CENTER);  // Vertically centered text ?

                                label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Add padding
                                // Change background and text color for selection
                                if (isSelected) {
                                        label.setBackground(new Color(85, 255, 23));// Set background color when selected
                                        label.setForeground(new Color(53, 115, 30)); // Set text color when selected
                                } else {
                                        label.setBackground(Color.WHITE); // Default background
                                        label.setForeground(Color.BLACK); // Default text color
                                }

                                return label;
                        }
                });
                JComboBox<String> cbEditTags = new JComboBox<>(cbEditTagsModel);

                Border panelBorder7 = BorderFactory.createTitledBorder("Developer Canvas");
                devGamePanel.setBorder(panelBorder7);

                devInfoTitle.setBounds(100, 50, 200, 100);
                devName.setBounds(50, 105, 200, 100);
                devScore.setBounds(50, 260, 200, 100);
                devRating.setBounds(50, 415, 200, 100);
                devPlaytime.setBounds(50, 570, 200, 100);
                devSize.setBounds(460, 105, 200,100);
                devPrice.setBounds(460, 260, 200, 100);
                devReviews.setBounds(310, 415, 220, 100);
                devTags.setBounds(550, 415, 200, 100);
                devEditAddTag.setBounds(760,480,200,100);
                devAddToTags.setBounds(760,585,200,100);
                cbEditTags.setBounds(760,680,200,100);
                devRemoveToTags.setBounds(760,760,200,100);
                devDisName.setBounds(50, 170, 200, 100);
                devDisScore.setBounds(50, 325, 200,100);
                devDisRating.setBounds(50, 480, 200, 100);
                devDisPlaytime.setBounds(50, 635, 200, 100);
                devDisSize.setBounds(460, 170, 200, 100);
                devDisPrice.setBounds(460, 325, 200, 100);
                devReviewDisplay.setBounds(310, 480, 200, 255);
                devTagsDisplay.setBounds(550, 480,200, 255);
                devBackToMain.setBounds(190, 800, 200, 100);
                completeChanges.setBounds(400, 800, 200, 100);

                devGamePanel.add(devInfoTitle);
                devGamePanel.add(devName);
                devGamePanel.add(devScore);
                devGamePanel.add(devRating);
                devGamePanel.add(devPlaytime);
                devGamePanel.add(devSize);
                devGamePanel.add(devPrice);
                devGamePanel.add(devReviews);
                devGamePanel.add(devTags);
                devGamePanel.add(devEditAddTag);
                devGamePanel.add(devAddToTags);
                devGamePanel.add(cbEditTags);
                devGamePanel.add(devRemoveToTags);
                devGamePanel.add(devDisName);
                devGamePanel.add(devDisScore);
                devGamePanel.add(devDisRating);
                devGamePanel.add(devDisPlaytime);
                devGamePanel.add(devDisSize);
                devGamePanel.add(devDisPrice);
                devGamePanel.add(devReviewDisplay);
                devGamePanel.add(devTagsDisplay);
                devGamePanel.add(devBackToMain);
                devGamePanel.add(completeChanges);


//----------------------FOR ADMIN ONLY----------------------------------------------------------------------------------


                // for the backend login panel
                backendLogin = new JPanel();
                backendLogin.setLayout(null);
                backendLogin.setBackground(adminColor);

                login_3 = new JLabel("What is your id?");
                login_3.setBackground(Color.LIGHT_GRAY);
                login_3.setFont(massiveFont);

                login3 = new JButton("Log In");
                login3.setOpaque(true);
                login3.setContentAreaFilled(true);
                login3.setBorder(new LineBorder(Color.darkGray, 4));
                login3.setFocusPainted(false);
                login3.setFont(biggerFont);

                back3 = new JButton("Back");
                back3.setOpaque(true);
                back3.setContentAreaFilled(true);
                back3.setBorder(new LineBorder(Color.darkGray, 4));
                back3.setFocusPainted(false);
                back3.setFont(biggerFont);

                id3 = new JTextField(10);
                id3.setOpaque(true);
                id3.setEditable(true);
                id3.setFont(biggerFont);
                id3.setBorder(new LineBorder(Color.darkGray, 4));

                Border panelBorder8 = BorderFactory.createTitledBorder("Administrator Login");
                backendLogin.setBorder(panelBorder8);

                login_3.setBounds(100, 150, 500,200);
                id3.setBounds(100,300,400,100);
                back3.setBounds(100,425,400,100);
                login3.setBounds(550, 300, 400, 100);

                backendLogin.add(login_3);
                backendLogin.add(login3);
                backendLogin.add(id3);
                backendLogin.add(back3);

                // for the backend main/third page
                backendMainScreen = new JPanel();
                backendMainScreen.setBackground(adminColor);
                backendMainScreen.setLayout(null);

                backendTitle = new JLabel("Admin Actions:");
                backendTitle.setBackground(Color.LIGHT_GRAY);
                backendTitle.setFont(biggerFont);

                addUser = new JButton("Add User");
                addUser.setOpaque(true);
                addUser.setContentAreaFilled(true);
                addUser.setBorder(new LineBorder(Color.darkGray, 4));
                addUser.setFocusPainted(false);
                addUser.setFont(biggerFont);
                addUser.setToolTipText("Add a New User");

                deleteUser = new JButton("Delete ID");
                deleteUser.setOpaque(true);
                deleteUser.setContentAreaFilled(true);
                deleteUser.setBorder(new LineBorder(Color.darkGray, 4));
                deleteUser.setFocusPainted(false);
                deleteUser.setFont(biggerFont);

                devPage = new JButton("Developer Homepage");
                devPage.setOpaque(true);
                devPage.setContentAreaFilled(true);
                devPage.setBorder(new LineBorder(Color.darkGray, 4));
                devPage.setFocusPainted(false);
                devPage.setFont(biggerFont);

                custPage = new JButton("Customer Homepage");
                custPage.setOpaque(true);
                custPage.setContentAreaFilled(true);
                custPage.setBorder(new LineBorder(Color.darkGray, 4));
                custPage.setFocusPainted(false);
                custPage.setFont(biggerFont);

                enterUser = new JTextField(20);
                enterUser.setOpaque(true);
                enterUser.setEditable(true);
                enterUser.setFont(biggerFont);
                enterUser.setBorder(new LineBorder(Color.darkGray, 4));

                backendLogout = new JButton("Log Out");
                backendLogout.setOpaque(true);
                backendLogout.setContentAreaFilled(true);
                backendLogout.setBorder(new LineBorder(Color.darkGray, 4));
                backendLogout.setFocusPainted(false);
                backendLogout.setFont(biggerFont);

                addDev = new JButton("Add Developer");
                addDev.setOpaque(true);
                addDev.setContentAreaFilled(true);
                addDev.setBorder(new LineBorder(Color.darkGray, 4));
                addDev.setFocusPainted(false);
                addDev.setFont(biggerFont);
                addDev.setToolTipText("Create a New Developer");

                Border panelBorder9 = BorderFactory.createTitledBorder("Administrator Main");
                backendMainScreen.setBorder(panelBorder9);

                backendTitle.setBounds(410,200,400,100);
                addUser.setBounds(145,300,250,100);
                custPage.setBounds(145,455,250,100);
                deleteUser.setBounds(400,455,200,100);
                devPage.setBounds(605,455,250,100);
                addDev.setBounds(605,300,250,100);
                enterUser.setBounds(400,300,200,100);
                backendLogout.setBounds(400,700,200,100);

                backendMainScreen.add(backendTitle);
                backendMainScreen.add(addUser);
                backendMainScreen.add(custPage);
                backendMainScreen.add(deleteUser);
                backendMainScreen.add(devPage);
                backendMainScreen.add(addDev);
                backendMainScreen.add(enterUser);
                backendMainScreen.add(backendLogout);

                // Add User
                addUserAdmin = new JPanel();
                addUserAdmin.setBackground(adminColor);
                addUserAdmin.setLayout(null);

                enterName = new JLabel("Name: ");
                enterName.setBackground(Color.LIGHT_GRAY);
                enterName.setFont(biggerFont);

                addTitle = new JLabel("New User Canvas");
                addTitle.setFont(massiveFont);


                enterId = new JLabel("ID: ");
                enterId.setBackground(Color.LIGHT_GRAY);
                enterId.setFont(biggerFont);

                complete = new JButton("Complete");
                complete.setOpaque(true);
                complete.setContentAreaFilled(true);
                complete.setBorder(new LineBorder(Color.darkGray, 4));
                complete.setFocusPainted(false);
                complete.setFont(biggerFont);
                complete.setToolTipText("Complete?");

                newUserId = new JTextField();
                newUserId.setOpaque(true);
                newUserId.setEditable(true);
                newUserId.setFont(biggerFont);
                newUserId.setBorder(new LineBorder(Color.darkGray, 4));

                newUserName = new JTextField();
                newUserName.setOpaque(true);
                newUserName.setEditable(true);
                newUserName.setFont(biggerFont);
                newUserName.setBorder(new LineBorder(Color.darkGray, 4));

                backToAdminActions = new JButton("Back");
                backToAdminActions.setOpaque(true);
                backToAdminActions.setContentAreaFilled(true);
                backToAdminActions.setBorder(new LineBorder(Color.darkGray, 4));
                backToAdminActions.setFocusPainted(false);
                backToAdminActions.setFont(biggerFont);

                Border panelBorder10 = BorderFactory.createTitledBorder("Administer Canvas");
                addUserAdmin.setBorder(panelBorder10);

                enterName.setBounds(195,250,200,100);
                newUserName.setBounds(195,310,250,100);
                enterId.setBounds(555,250,200,100);
                newUserId.setBounds(555, 310, 250,100);
                complete.setBounds(555,470,250,100);
                backToAdminActions.setBounds(195,470,250,100);
                addTitle.setBounds(300,150,1000,100);


                addUserAdmin.add(enterName);
                addUserAdmin.add(newUserName);
                addUserAdmin.add(enterId);
                addUserAdmin.add(newUserId);
                addUserAdmin.add(complete);
                addUserAdmin.add(backToAdminActions);
                addUserAdmin.add(addTitle);

                //Add dev------------------------------------------------------------------------------------
                addDevAdmin = new JPanel();
                addDevAdmin.setBackground(adminColor);
                addDevAdmin.setLayout(null);

                enterDevId = new JLabel("Enter New Dev Id");
                enterDevId.setBackground(Color.LIGHT_GRAY);
                enterDevId.setFont(biggerFont);

                addTitleDev = new JLabel("New developer canvas");
                addTitleDev.setFont(massiveFont);

                newDevId = new JTextField();
                newDevId.setOpaque(true);
                newDevId.setEditable(true);
                newDevId.setFont(biggerFont);
                newDevId.setBorder(new LineBorder(Color.darkGray, 4));

                devComplete = new JButton("Complete");
                devComplete.setOpaque(true);
                devComplete.setContentAreaFilled(true);
                devComplete.setBorder(new LineBorder(Color.darkGray, 4));
                devComplete.setFocusPainted(false);
                devComplete.setFont(biggerFont);

                backToAdminActionsDev = new JButton("Back");
                backToAdminActionsDev.setOpaque(true);
                backToAdminActionsDev.setContentAreaFilled(true);
                backToAdminActionsDev.setBorder(new LineBorder(Color.darkGray, 4));
                backToAdminActionsDev.setFocusPainted(false);
                backToAdminActionsDev.setFont(biggerFont);

                Border panelBorder12 = BorderFactory.createTitledBorder("Administer Canvas");
                addDevAdmin.setBorder(panelBorder12);

                enterDevId.setBounds(230,310,250,100);
                newDevId.setBounds(555,310,250,100);
                devComplete.setBounds(555,470,250,100);
                backToAdminActionsDev.setBounds(195,470,250,100);
                addTitleDev.setBounds(250,150,1000,100);

                addDevAdmin.add(enterDevId);
                addDevAdmin.add(newDevId);
                addDevAdmin.add(devComplete);
                addDevAdmin.add(backToAdminActionsDev);
                addDevAdmin.add(addTitleDev);

                //Add all to the main panel
                f.add(cardLayout);
                cardLayout.add(signInPanel, "1");
                cardLayout.add(customerLogin, "2");
                cardLayout.add(devLogin, "3");
                cardLayout.add(backendLogin, "4");
                cardLayout.add(customerMainScreen, "5");
                cardLayout.add(devMain, "6");
                cardLayout.add(backendMainScreen, "7");
                cardLayout.add(customerInfoPanel, "8");
                cardLayout.add(transactionPanel, "9");
                cardLayout.add(devGamePanel, "10");
                cardLayout.add(addUserAdmin, "11");
                cardLayout.add(addDevAdmin, "12");


                // Action listeners for the Who Are you Page

// leave as is, no SQL
                customer.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "2");
                        }
                });
                dev.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "3");
                        }
                });
                backendUser.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "4");
                        }
                });

                //Action Lister for the Back Buttons and other Buttons in Login Screens
                // SQL IS NOT NEEDED HERE
                back1.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "1");
                        }
                });
                back2.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "1");
                        }
                });
                back3.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "1");
                        }
                });


                login1.addActionListener(new ActionListener() {
                        String mainDatabase = "MAIN_DATABASE";
                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                        Statement stm;
                        Connection conn = null;
                        PreparedStatement psstm;
                        public void actionPerformed(ActionEvent e) {
                                if (id1.getText().equals("")) {
                                        JOptionPane.showMessageDialog(null, "Enter a valid ID");
                                }
                                else{
                                        ResultSet myResult, myResult1, myResult2;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                myResult = stm.executeQuery("select ID from CUST where ID="+id1.getText());
                                                user = id1.getText();
                                                if(!myResult.next())
                                                {
                                                        JOptionPane.showMessageDialog(null, "Invalid Login");
                                                }
                                                else {
                                                        cardLayout4use.show(cardLayout, "5");
                                                        tagModel.clear();
                                                        gameModel.clear();
                                                        cbRemoveTags.removeAllElements();
                                                        gameTagsInfo.clear();
                                                        id1.setText("");
                                                        myResult1 = stm.executeQuery("select * from CUST where ID = "+ user);
                                                        String[] tags = new String[0];
                                                        while(myResult1.next()){
                                                                String tagsList = myResult1.getString("TAGS");
                                                                if(tagsList.equals(null)){
                                                                        System.out.println("minor error");
                                                                }
                                                                else{
                                                                        tags = tagsList.split(",");
                                                                        for (String eachTag : tags ){
                                                                                tagModel.addElement(eachTag);
                                                                                cbRemoveTags.addElement(eachTag);
                                                                        }
                                                                }
                                                        }
                                                        ArrayList<String> validGames = new ArrayList<String>();
                                                        myResult2 = stm.executeQuery("select * from GAME");
                                                        while(myResult2.next()){
                                                                String temp = myResult2.getString("GAMETAGS");
                                                                String tempName = myResult2.getString("GAMENAME");
//                                                        String [] tempGameTags = temp.split(",");
//                                                        for(String gametag : tempGameTags){
//                                                                for(String tempGameTag : tags)
//                                                                        if(gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())){
//                                                                                    validGames.add(tempName);
//                                                                        }
//                                                                }
                                                                if (temp != null) { // Check if temp is not null
                                                                        String[] tempGameTags = temp.split(",");
                                                                        for (String gametag : tempGameTags) {
                                                                                for (String tempGameTag : tags) {
                                                                                        if (gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())) {
                                                                                                validGames.add(tempName);
                                                                                        }
                                                                                }
                                                                        }
                                                                } else {
                                                                        System.out.println("Skipping game with null tags: " + tempName);
                                                                }

                                                        }
                                                        for (String game : validGames){
                                                                gameModel.addElement(game);
                                                        }
                                                        validGames.clear();
                                                        tags = new String[0];
                                                        stm.close();
                                                        myResult.close();
                                                        myResult1.close();
                                                        myResult2.close();
                                                }
                                                //  myResult1 = stm.executeQuery("select PSU_ID, NAME, GENDER from STUD");
                                        } catch (Exception ex)
                                        {
                                                System.out.println("something Went Wrong");
                                                ex.printStackTrace();
                                        }
                                }

                        }
                });
                login2.addActionListener(new ActionListener() {
                        String mainDatabase = "MAIN_DATABASE";
                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                        Statement stm;
                        Connection conn = null;
                        PreparedStatement psstm;
                        public void actionPerformed(ActionEvent e) {
                                if (!id2.getText().isEmpty()) {
                                        ResultSet myResult, myResult1, myResult2 = null;
                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                myResult = stm.executeQuery("select DEVID from DEV where DEVID=" + id2.getText());
                                                if (!myResult.next()) {
                                                        JOptionPane.showMessageDialog(null, "Invalid Login");
                                                } else {
                                                        ownedGamesModel.clear();
                                                        devGameTags.clear();
                                                        developer = Integer.valueOf(id2.getText());
                                                        id2.setText("");
                                                        cardLayout4use.show(cardLayout, "6");


                                                        myResult1 = stm.executeQuery("select * from DEV where DEVID = " + developer);
                                                        String[] games = new String[0];
                                                        ownedGamesModel.clear();
                                                        while (myResult1.next()) {

                                                                String gamesList = myResult1.getString("OWNEDGAMES");
                                                                games = gamesList.split(",");
                                                                for (String eachGame : games) {
                                                                        ownedGamesModel.addElement(eachGame);
                                                                }
                                                        }
                                                        games = new String[0];
                                                        stm.close();
                                                        myResult.close();
                                                        myResult1.close();
                                                }
                                        } catch (Exception ex) {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                                }
                                else {
                                        JOptionPane.showMessageDialog(null, "Enter a valid ID");
                                }
                        }
                });
                login3.addActionListener(new ActionListener() {
                        String mainDatabase = "MAIN_DATABASE";
                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                        Statement stm;
                        Connection conn = null;
                        PreparedStatement psstm = null;
                        ResultSet myResult;
                        public void actionPerformed (ActionEvent e){
                                try {
                                        conn = DriverManager.getConnection(connectionURL);
                                        stm = conn.createStatement();
                                        psstm = conn.prepareStatement("select BACKENDNAME from BACKEND where BACKENDNAME = ?");
                                        psstm.setString(1, id3.getText());
                                        myResult = psstm.executeQuery();
                                        if (!myResult.next() || id3.getText().equals("")) {
                                                JOptionPane.showMessageDialog(null, "Enter a valid ID");
                                        } else {
                                                cardLayout4use.show(cardLayout, "7");
                                        }
                                        id3.setText("");
                                        psstm.close();
                                        stm.close();
                                        conn.close();
                                        myResult.close();

                                } catch (Exception ex) {
                                        System.out.println("ERROR");
                                        ex.printStackTrace();
                                }
                        }
                });


                //Customer Main Screen Buttons


                info.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                                if(gamesList.getSelectedValue() == null){
                                        JOptionPane.showMessageDialog(null, "Please select a game. If none are available, change your tags");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm = null;
                                        Connection conn = null;
                                        ResultSet myResult = null, myResult1 = null, myResult2 = null;
                                        String Subject = gamesList.getSelectedValue();
                                        ArrayList<Double> arrayScores = new ArrayList<Double>();
                                        Double scoresStorage = 0.0;
                                        gameReview.clear();
                                        gameTagsInfo.clear();
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();


                                                PreparedStatement psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, gamesList.getSelectedValue());
                                                myResult = psstm.executeQuery();
                                                if(myResult.next()){
                                                        disName.setText(myResult.getString("GAMENAME"));
                                                        disRating.setText(myResult.getString("GAMERATING"));
                                                        disPlaytime.setText(myResult.getString("GAMEPLAYTIME"));
                                                        disSize.setText(myResult.getString("GAMEGB"));
                                                        disPrice.setText(myResult.getString("GAMEPRICE"));
                                                }
                                                PreparedStatement psstm2 = conn.prepareStatement("select GAMETAGS, GAMEUSERSCORE from GAME where GAMENAME = ?");
                                                psstm2.setString(1, gamesList.getSelectedValue());
                                                myResult1 = psstm2.executeQuery();
                                                while (myResult1.next())
                                                {
                                                        String tagsList = myResult1.getString("GAMETAGS");
                                                        String [] gameTagsInTb = tagsList.split(",");
                                                        for (String eachTag : gameTagsInTb ){
                                                                gameTagsInfo.addElement(eachTag);
                                                        }

                                                        String scoresList = myResult1.getString("GAMEUSERSCORE");
                                                        if(scoresList != null)
                                                        {
                                                                String[] scores = scoresList.split(",");
                                                                for (String eachScore : scores){
                                                                        arrayScores.add(Double.valueOf(eachScore));
                                                                }
                                                        }
                                                }
                                                if(!arrayScores.isEmpty())
                                                {
                                                        for(int i = 0; i < arrayScores.size(); i++){
                                                                scoresStorage += arrayScores.get(i);
                                                                gameReview.addElement(String.valueOf(arrayScores.get(i)));
                                                        }
                                                        scoresStorage /= arrayScores.size();
                                                }
                                                long newint = Math.round(scoresStorage);
                                                disScore.setText(String.valueOf(newint));

                                                scoresStorage = 0.0;
                                                arrayScores.clear();
                                                psstm.close();
                                                psstm2.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();
                                                myResult1.close();

                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                        finally{
                                                cardLayout4use.show(cardLayout, "8");
                                        }
                                }
                        }
                });
                // done for both buy and rent
                buy.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (gamesList.getSelectedValue() == null)
                                {
                                        JOptionPane.showMessageDialog(null, "Select a game to proceed to transaction");
                                }
                                else {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm;
                                        Connection conn = null;
                                        PreparedStatement psstm = null;
                                        ResultSet myResult;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, gamesList.getSelectedValue());
                                                myResult = psstm.executeQuery();
                                                if(myResult.next())
                                                priceOfGame.setText("$" + myResult.getString("GAMEPRICE"));

                                                psstm.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();

                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        } finally {
                                                cardLayout4use.show(cardLayout, "9");
                                                gameSelection.setText(gamesList.getSelectedValue());
                                        }
                                };
                                }

                });
                rent.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (gamesList.getSelectedValue() == null)
                                {
                                        JOptionPane.showMessageDialog(null, "Select a game to proceed to transaction");
                                }
                                else {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm;
                                        Connection conn = null;
                                        PreparedStatement psstm = null;
                                        ResultSet myResult;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, gamesList.getSelectedValue());
                                                myResult = psstm.executeQuery();

                                                if(myResult.next())
                                                        priceOfGame.setText("$" + myResult.getString("GAMEPRICE"));

                                                psstm.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();
                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        } finally {
                                                cardLayout4use.show(cardLayout, "9");
                                                gameSelection.setText(gamesList.getSelectedValue());
                                        }
                                };
                        }

                });
                addTags.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (tagsEnter.getText() == null)
                                {
                                        JOptionPane.showMessageDialog(null, "Please enter a tag");
                                }
                                else if (tagModel.contains((tagsEnter.getText()).trim())){ // needs insensitive testing
                                        JOptionPane.showMessageDialog(null, "The tag you are trying to enter already exists");
                                }
                                else {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm, stm2, stm3;
                                        Connection conn = null;
                                        PreparedStatement psstm = null;
                                        ResultSet myResult, myResult1, myResult2;
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                tagModel.addElement(tagsEnter.getText().trim().toLowerCase());
                                                cbRemoveTags.addElement(tagsEnter.getText().trim().toLowerCase());
                                                StringBuilder longArrayTags = new StringBuilder();
                                                for(int i = 0; i < tagModel.size(); i++){
                                                        longArrayTags.append(tagModel.getElementAt(i));
                                                        if(i < tagModel.size() - 1)
                                                                longArrayTags.append(",");
                                                }
                                                String strToSend = longArrayTags.toString();
                                                psstm = conn.prepareStatement("UPDATE CUST SET TAGS = (?) WHERE ID = " + user);

                                                psstm.setString(1, strToSend);
                                                psstm.executeUpdate();

                                                // now update the model of games depending on the tags again
                                                //--------------------------------
                                                System.out.println("made it to where the rerendering happens");
                                                stm2 = conn.createStatement();
                                                myResult = stm2.executeQuery("select ID from CUST where ID=" + user);
                                                if (!myResult.next()) {
                                                        JOptionPane.showMessageDialog(null, "Invalid Login");
                                                } else {
                                                        tagModel.clear();
                                                        gameModel.clear();
                                                        cbRemoveTags.removeAllElements();
                                                        gameTagsInfo.clear();
                                                        System.out.println(user);
                                                        stm3 = conn.createStatement();
                                                        myResult1 = stm3.executeQuery("select * from CUST where ID=" + user);
                                                        String[] tags = new String[0];
                                                        while (myResult1.next()) {
                                                                String tagsList = myResult1.getString("TAGS");
                                                                tags = tagsList.split(",");
                                                                for (String eachTag : tags) {
                                                                        tagModel.addElement(eachTag);
                                                                        cbRemoveTags.addElement(eachTag);
                                                                }
                                                        }
                                                        ArrayList<String> validGames = new ArrayList<String>();
                                                        myResult2 = stm.executeQuery("select * from GAME");
                                                        while (myResult2.next()) {
                                                                String temp = myResult2.getString("GAMETAGS");
                                                                String tempName = myResult2.getString("GAMENAME");
                                                                String[] tempGameTags = temp.split(",");
                                                                for (String gametag : tempGameTags) {
                                                                        for (String tempGameTag : tags)
                                                                                if (gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())) {
                                                                                        validGames.add(tempName);
                                                                                }
                                                                }

                                                        }
                                                        for (String game : validGames) {
                                                                gameModel.addElement(game);
                                                        }
                                                        validGames.clear();
                                                        tags = new String[0];
                                                        myResult.close();
                                                        myResult1.close();
                                                        myResult2.close();
                                                        //---------------------------------
                                                        psstm.close();
                                                        stm.close();
                                                        conn.close();
                                                        stm2.close();
                                                        stm3.close();
                                                }
                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        } finally {
                                                tagsEnter.setText("");
                                        }
                                }
                                }
                });
                removeTag.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                String mainDatabase = "MAIN_DATABASE";
                                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                Statement stm, stm2, stm3;
                                Connection conn = null;
                                PreparedStatement psstm = null;
                                ResultSet myResult, myResult1, myResult2;
                                try {
                                        conn = DriverManager.getConnection(connectionURL);
                                        stm = conn.createStatement();
                                        tagModel.removeElement(tagsToRemove.getSelectedItem());
                                        cbRemoveTags.removeElement(tagsToRemove.getSelectedItem());
                                        // coverting an array to string with dem commas
                                        StringBuilder longArrayTags = new StringBuilder();
                                        for (int i = 0; i < tagModel.size(); i++) {
                                                longArrayTags.append(tagModel.getElementAt(i));
                                                if (i < tagModel.size() - 1)
                                                        longArrayTags.append(",");
                                        }
                                        String strToSend = longArrayTags.toString();
                                        psstm = conn.prepareStatement("UPDATE CUST SET TAGS = (?) WHERE ID = " + user);
                                        psstm.setString(1, strToSend);
                                        psstm.executeUpdate();

                                        // now update the model of games depending on the tags again
                                        //--------------------------------
                                        stm2 = conn.createStatement();
                                        myResult = stm2.executeQuery("select ID from CUST where ID=" + user);
                                        if (!myResult.next()) {
                                                JOptionPane.showMessageDialog(null, "Invalid Login");
                                        } else {
                                                tagModel.clear();
                                                gameModel.clear();
                                                cbRemoveTags.removeAllElements();
                                                gameTagsInfo.clear();
                                                stm3 = conn.createStatement();
                                                myResult1 = stm3.executeQuery("select * from CUST where ID=" + user);
                                                String[] tags = new String[0];
                                                while (myResult1.next()) {
                                                        String tagsList = myResult1.getString("TAGS");
                                                        tags = tagsList.split(",");
                                                        for (String eachTag : tags) {
                                                                tagModel.addElement(eachTag);
                                                                cbRemoveTags.addElement(eachTag);
                                                        }
                                                }
                                                ArrayList<String> validGames = new ArrayList<String>();
                                                myResult2 = stm.executeQuery("select * from GAME");
                                                while (myResult2.next()) {
                                                        String temp = myResult2.getString("GAMETAGS");
                                                        String tempName = myResult2.getString("GAMENAME");
                                                        String[] tempGameTags = temp.split(",");
                                                        for (String gametag : tempGameTags) {
                                                                for (String tempGameTag : tags)
                                                                        if (gametag.trim().equals(tempGameTag.trim()) && !validGames.contains(tempName.trim())) {
                                                                                validGames.add(tempName);
                                                                        }
                                                        }

                                                }
                                                for (String game : validGames) {
                                                        gameModel.addElement(game);
                                                }
                                                validGames.clear();
                                                tags = new String[0];
                                                myResult.close();
                                                myResult1.close();
                                                myResult2.close();
                                                //---------------------------------
                                                psstm.close();
                                                stm2.close();
                                                conn.close();
                                                }
                                        } catch(Exception ex)
                                        {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                        }
                });
                completeTransaction.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (cardEntry.getText().trim().isEmpty())
                                {
                                        JOptionPane.showMessageDialog(null, "Please enter a valid card number");
                                }
                                else {
                                        JOptionPane.showMessageDialog(null, "Success!!");
                                        cardLayout4use.show(cardLayout, "5");
                                        cardEntry.setText("");
                                }
                        }
                });
                cancel.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "5"); }
                });
                backToMain.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "5"); }
                });
                logout.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "1");
                        user = null;}
                });


                //Dev Main Panel Buttons

// test this
                editGameButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                //ADD FILLING OR KEEPING THE BOXES EMPTY
                                if(ownedGames.getSelectedValue() == null){
                                        JOptionPane.showMessageDialog(null, "Please select a game to edit.");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm = null;
                                        Connection conn = null;
                                        ResultSet myResult = null, myResult1 = null;
                                        String subject = ownedGames.getSelectedValue();
                                        ArrayList<Double> arrayScores = new ArrayList<Double>();
                                        Double scoresStorage = 0.0;
                                        devGameTags.clear();
                                        devGameReviews.clear();
                                        cbEditTagsModel.removeAllElements();
                                        try{
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                PreparedStatement psstm = conn.prepareStatement("select * from GAME where GAMENAME = ?");
                                                psstm.setString(1, ownedGames.getSelectedValue());
                                                myResult = psstm.executeQuery();
                                                if(myResult.next()){
                                                        devDisName.setText(myResult.getString("GAMENAME"));
                                                        devDisRating.setText(myResult.getString("GAMERATING"));
                                                        devDisPlaytime.setText(myResult.getString("GAMEPLAYTIME"));
                                                        devDisSize.setText(myResult.getString("GAMEGB"));
                                                        devDisPrice.setText(myResult.getString("GAMEPRICE"));
                                                }
                                                PreparedStatement psstm2 = conn.prepareStatement("select GAMETAGS, GAMEUSERSCORE from GAME where GAMENAME = ?");
                                                psstm2.setString(1, ownedGames.getSelectedValue());
                                                myResult1 = psstm2.executeQuery();
                                                while (myResult1.next())
                                                {
                                                        String devTagsDisplay = myResult1.getString("GAMETAGS");
                                                        String [] gameTagsInTb = devTagsDisplay.split(",");
                                                        for (String eachTag : gameTagsInTb ){
                                                                devGameTags.addElement(eachTag);
                                                                cbEditTagsModel.addElement(eachTag);
                                                        }

                                                        String scoresList = myResult1.getString("GAMEUSERSCORE");
                                                        if(scoresList != null)
                                                        {
                                                                String[] scores = scoresList.split(",");
                                                                for (String eachScore : scores){
                                                                        arrayScores.add(Double.valueOf(eachScore));
                                                                }
                                                        }
                                                }
                                                if(!arrayScores.isEmpty())
                                                {
                                                        for(int i = 0; i < arrayScores.size(); i++){
                                                                scoresStorage += arrayScores.get(i);
                                                                devGameReviews.addElement(String.valueOf(arrayScores.get(i)));
                                                        }
                                                        scoresStorage /= arrayScores.size();
                                                }
                                                long newint = Math.round(scoresStorage);
                                                devDisScore.setText(String.valueOf(newint));

                                                scoresStorage = 0.0;
                                                arrayScores.clear();
                                                psstm.close();
                                                psstm2.close();
                                                stm.close();
                                                conn.close();
                                                myResult.close();
                                                myResult1.close();

                                        } catch (Exception ex)
                                        {
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                        finally{
                                                add_edit = 0;
                                                cardLayout4use.show(cardLayout, "10");
                                        }
                                }
                        }
                });
                devAddToTags.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if(devEditAddTag.getText().trim().equals("") || devGameTags.contains(devEditAddTag.getText().trim())){
                                        JOptionPane.showMessageDialog(null, "Please enter a valid tag to add");
                                }else{
                                        devGameTags.addElement(devEditAddTag.getText().trim().toLowerCase());
                                        cbEditTagsModel.addElement(devEditAddTag.getText().trim().toLowerCase());
                                        devEditAddTag.setText("");
                                }
                        }
                });
                devRemoveToTags.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                devGameTags.removeElement(cbEditTags.getSelectedItem());
                                cbEditTagsModel.removeElement(cbEditTags.getSelectedItem());
                        }
                });
                completeChanges.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                String mainDatabase = "MAIN_DATABASE";
                                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                Connection conn = null;
                                ResultSet myResult1 = null, myResult2 = null;

                                if (devDisName.getText().equals(null)) {
                                        JOptionPane.showMessageDialog(null, "Please Enter a Name");
                                } else if (devDisScore.getText().toLowerCase().matches("[a-z]+") || devDisScore.getText().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, "Please Enter a Numerical Score");
                                } else if (devDisRating.getText().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, "Please Enter a Letter Rating (E, PG-13, M, etc)");
                                } else if (devDisPlaytime.getText().toLowerCase().matches("[a-z]+") || devDisPlaytime.getText().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, "Please Enter Numerical Playtime");
                                } else if (devDisSize.getText().toLowerCase().matches("[a-z]+") || devDisSize.getText().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, "Please Enter Numeracial Size");
                                } else if (devDisPrice.getText().toLowerCase().matches("[a-z]+") || devDisPrice.getText().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, "Please Enter a Numeracial Price");
                                } else {
                                        if (add_edit == 0) {
                                                try {
                                                        conn = DriverManager.getConnection(connectionURL);
                                                        PreparedStatement psstm3 = conn.prepareStatement("select * from DEV where DEVID = ?");
                                                        psstm3.setInt(1, developer);
                                                        myResult1 = psstm3.executeQuery();
                                                        String str = null;
                                                        if (myResult1.next()) {
                                                                String gamesList = myResult1.getString("OWNEDGAMES");
                                                                String[] temp = new String[0];
                                                                temp = gamesList.split(",");
                                                                StringBuilder newTemp = new StringBuilder();
                                                                for (int i = 0; i < temp.length; i++) {
                                                                        if (temp[i].equals(ownedGames.getSelectedValue())) {
                                                                                newTemp.append(devDisName.getText() + ",");
                                                                        } else {
                                                                                newTemp.append(temp[i]);
                                                                                if (i < temp.length - 1) {
                                                                                        newTemp.append(",");
                                                                                }
                                                                        }
                                                                }
                                                                str = newTemp.toString();
                                                        }
                                                        // converting the tagmodel into a string
                                                        StringBuilder tagsForGame = new StringBuilder();
                                                        for (int i = 0; i < devGameTags.size(); i++) {
                                                                tagsForGame.append(devGameTags.getElementAt(i));
                                                                if (i < devGameTags.size() - 1)
                                                                        tagsForGame.append(",");
                                                        }
                                                        String strToSend = tagsForGame.toString();

                                                        PreparedStatement psstm1 = conn.prepareStatement("UPDATE GAME SET GAMENAME = ?, GAMESCORE = ?, GAMERATING = ?, GAMEPLAYTIME = ?, GAMEGB = ?, GAMEPRICE = ?, GAMETAGS = ? WHERE GAMENAME = ?");
                                                        PreparedStatement psstm2 = conn.prepareStatement("UPDATE DEV SET OWNEDGAMES = ? WHERE DEVID = " + developer);
                                                        psstm1.setString(8, ownedGames.getSelectedValue());
                                                        psstm1.setString(1, devDisName.getText());
                                                        psstm1.setDouble(2, Double.parseDouble(devDisScore.getText()));
                                                        psstm1.setString(3, devDisRating.getText());
                                                        psstm1.setInt(4, Integer.parseInt(devDisPlaytime.getText()));
                                                        psstm1.setInt(5, Integer.parseInt(devDisSize.getText()));
                                                        psstm1.setDouble(6, Double.parseDouble(devDisPrice.getText()));
                                                        psstm1.setString(7, strToSend);
                                                        psstm2.setString(1, str);
                                                        psstm1.executeUpdate();
                                                        psstm2.executeUpdate();

                                                        ownedGamesModel.clear();
                                                        String[] temp2 = str.split(",");
                                                        for (String newGame : temp2) {
                                                                ownedGamesModel.addElement(newGame);
                                                        }

                                                        devDisName.setText("");
                                                        devDisScore.setText("");
                                                        devDisRating.setText("");
                                                        devDisPlaytime.setText("");
                                                        devDisSize.setText("");
                                                        devDisPrice.setText("");
                                                        psstm1.close();
                                                        psstm2.close();
                                                        psstm3.close();
                                                        myResult1.close();
                                                        conn.close();

                                                } catch (Exception ex) {
                                                        System.out.println("ERROR!");
                                                        ex.printStackTrace();
                                                } finally {
                                                        cardLayout4use.show(cardLayout, "6");
                                                        JOptionPane.showMessageDialog(null, "Success!!");
                                                }
                                        } else {
                                                try {
                                                        conn = DriverManager.getConnection(connectionURL);

                                                        PreparedStatement psstm3 = conn.prepareStatement("select * from DEV where DEVID = ?");
                                                        psstm3.setInt(1, developer);
                                                        myResult1 = psstm3.executeQuery();
                                                        String str = null;
                                                        if (myResult1.next()) {
                                                                String gamesList = myResult1.getString("OWNEDGAMES");
                                                                String[] temp = new String[0];
                                                                temp = gamesList.split(",");
                                                                StringBuilder newTemp = new StringBuilder();
                                                                for (int i = 0; i < temp.length; i++) {
                                                                        newTemp.append(temp[i]);
                                                                        if (i < temp.length - 1) {
                                                                                newTemp.append(",");
                                                                        }
                                                                }
                                                                newTemp.append("," + devDisName.getText());
                                                                str = newTemp.toString();
                                                        }

                                                        StringBuilder tagsForGame = new StringBuilder();
                                                        for (int i = 0; i < devGameTags.size(); i++) {
                                                                tagsForGame.append(devGameTags.getElementAt(i));
                                                                if (i < devGameTags.size() - 1)
                                                                        tagsForGame.append(",");
                                                        }
                                                        String strToSend = tagsForGame.toString();

                                                        PreparedStatement psstm2 = conn.prepareStatement("UPDATE DEV SET OWNEDGAMES = ? WHERE DEVID = " + developer);
                                                        PreparedStatement psstm = conn.prepareStatement("INSERT into GAME (GAMENAME, GAMESCORE, GAMERATING, GAMEPLAYTIME, GAMEGB, GAMEPRICE, GAMETAGS) VALUES (?,?,?,?,?,?,?)");
                                                        Statement stm = conn.createStatement();
                                                        String query = "SELECT GAMENAME FROM GAME";
                                                        myResult1 = stm.executeQuery(query);
                                                        boolean valid = true;
                                                        while (myResult1.next()) {
                                                                if (devDisName.getText().equals(myResult1.getString(1))) {
                                                                        JOptionPane.showMessageDialog(null, "Game already exists! please enter another name");
                                                                        valid = false;
                                                                }
                                                        }
                                                        if (valid) {
                                                                psstm.setString(1, devDisName.getText());
                                                                psstm.setDouble(2, Double.parseDouble(devDisScore.getText()));
                                                                psstm.setString(3, devDisRating.getText());
                                                                psstm.setInt(4, Integer.parseInt(devDisPlaytime.getText()));
                                                                psstm.setInt(5, Integer.parseInt(devDisSize.getText()));
                                                                psstm.setDouble(6, Double.parseDouble(devDisPrice.getText()));
                                                                psstm.setString(7, strToSend);
                                                                psstm2.setString(1, str);
                                                                psstm.executeUpdate();
                                                                psstm2.executeUpdate();

                                                                ownedGamesModel.clear();
                                                                String[] temp2 = str.split(",");
                                                                for (String newGame : temp2) {
                                                                        ownedGamesModel.addElement(newGame);
                                                                }

                                                                cardLayout4use.show(cardLayout, "6");
                                                                JOptionPane.showMessageDialog(null, "Success!!");
                                                        }

                                                        devDisName.setText("");
                                                        devDisScore.setText("");
                                                        devDisRating.setText("");
                                                        devDisPlaytime.setText("");
                                                        devDisSize.setText("");
                                                        devDisPrice.setText("");
                                                        myResult1.close();
                                                        psstm.close();
                                                        conn.close();
                                                } catch (Exception ex) {
                                                        System.out.println("ERROR");
                                                        ex.printStackTrace();
                                                }
                                        }
                                }
                        }
                });
                addGameButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                // clearing all parts of the info page for safety
                                devDisPrice.setText("");
                                devDisSize.setText("");
                                devDisPlaytime.setText("");
                                devDisRating.setText("");
                                devDisScore.setText("");
                                devDisName.setText("");
                                devGameTags.clear();
                                devGameReviews.clear();
                                cbEditTagsModel.removeAllElements();
                                add_edit = 1;
                                // going to the panel
                                cardLayout4use.show(cardLayout, "10");
                        }
                });
                deleteGameButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                String mainDatabase = "MAIN_DATABASE";
                                String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                Statement stm;
                                Connection conn = null;
                                ResultSet myResult1;
                                try{
                                        conn = DriverManager.getConnection(connectionURL);
                                        stm = conn.createStatement();

                                        PreparedStatement psstm3 = conn.prepareStatement("select * from DEV where DEVID = ?");
                                        psstm3.setInt(1, developer);
                                        myResult1 = psstm3.executeQuery();
                                        String str = null;
                                        if (myResult1.next()) {
                                                String gamesList = myResult1.getString("OWNEDGAMES");
                                                String[] temp = new String[0];
                                                temp = gamesList.split(",");
                                                StringBuilder newTemp = new StringBuilder();
                                                for (int i = 0; i < temp.length; i++) {
                                                        if (temp[i].equals(ownedGames.getSelectedValue())) {}
                                                        else {
                                                                newTemp.append(temp[i]);
                                                                if (i < temp.length - 1) {
                                                                        newTemp.append(",");
                                                                }
                                                        }
                                                }
                                                str = newTemp.toString();
                                        }



                                        PreparedStatement psstm = conn.prepareStatement("UPDATE DEV SET OWNEDGAMES = ? WHERE DEVID = " + developer);
                                        PreparedStatement psstm2 = conn.prepareStatement("DELETE FROM GAME WHERE GAMENAME = ?");
                                        psstm2.setString(1, ownedGames.getSelectedValue());
                                        int rowsAffected = psstm2.executeUpdate();

                                        if (rowsAffected > 0) {
                                                JOptionPane.showMessageDialog(null, "Record deleted successfully.");
                                        } else {
                                                JOptionPane.showMessageDialog(null, "No record found with the given game.");
                                        }

                                        psstm.setString(1, str);
                                        psstm.executeUpdate();

                                        ownedGamesModel.clear();
                                        String[] temp2 = str.split(",");
                                        for (String newGame : temp2) {
                                                ownedGamesModel.addElement(newGame);
                                        }

                                        psstm.close();
                                        psstm2.close();
                                        psstm3.close();
                                        myResult1.close();
                                        stm.close();
                                        conn.close();
                                }
                                catch (Exception ex)
                                {
                                        System.out.println("ERROR");
                                        ex.printStackTrace();
                                }
                        }
                });
                devLogout.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "1"); }
                });
                devBackToMain.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                cardLayout4use.show(cardLayout, "6");
                                devDisName.setText("");
                                devDisScore.setText("");
                                devDisRating.setText("");
                                devDisPlaytime.setText("");
                                devDisSize.setText("");
                                devDisPrice.setText("");
                        }
                });


                //Backend main panel buttons


                addUser.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "11"); }
                });
                deleteUser.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                //DELETE USER FUNCTIONALLITY GOES HERE
                                if (!enterUser.getText().equals("")) {
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Statement stm;
                                        Connection conn = null;
                                        ResultSet myResult;
                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                stm = conn.createStatement();
                                                PreparedStatement psstm = conn.prepareStatement("DELETE FROM CUST WHERE ID = ?");
                                                PreparedStatement psstm2 = conn.prepareStatement("DELETE FROM DEV WHERE DEVID = ?");
                                                psstm.setString(1, enterUser.getText());
                                                psstm2.setString(1, enterUser.getText());
                                                int rowsAffected = psstm.executeUpdate();
                                                int rowsAffectedDev = psstm2.executeUpdate();

                                                if (rowsAffected > 0) {
                                                        JOptionPane.showMessageDialog(null, "Customer record deleted successfully.");
                                                }
                                                else if(rowsAffectedDev > 0){
                                                        JOptionPane.showMessageDialog(null, "Dev record deleted successfully.");
                                                }
                                                else {
                                                        JOptionPane.showMessageDialog(null, "No record found with the given ID.");
                                                }

                                                enterUser.setText("");
                                                stm.close();
                                                psstm.close();
                                                psstm2.close();
                                                conn.close();

                                        } catch (Exception ex) {
                                                System.out.println("ERROR");
                                                ex.printStackTrace();
                                        }
                                }
                                else{
                                        JOptionPane.showMessageDialog(null,"Enter an ID please");
                                }
                        }

                });
                custPage.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                tagModel.clear();
                                gameModel.clear();
                                cbRemoveTags.removeAllElements();
                                tagsEnter.setText("");
                                cardLayout4use.show(cardLayout, "5");
                        }
                });
                devPage.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                ownedGamesModel.clear();
                                cardLayout4use.show(cardLayout, "6");
                        }
                });
                backToAdminActions.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "7"); }
                });
                complete.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (newUserName.getText().equals("") || newUserId.getText().equals("")) {
                                        JOptionPane.showMessageDialog(null, "Please enter a name and an ID");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Connection conn = null;
                                        ResultSet myResult1 = null, myResult2 = null;

                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                PreparedStatement psstm = conn.prepareStatement("INSERT into CUST (ID, NAME, TAGS) VALUES (?,?,?)");
                                                Statement stm = conn.createStatement();
                                                Statement stm2 = conn.createStatement();
                                                String query = "SELECT ID FROM CUST";
                                                String query2 = "SELECT DEVID FROM DEV";
                                                myResult1 = stm.executeQuery(query);
                                                myResult2 = stm2.executeQuery(query2);
                                                boolean valid = true;
                                                while (myResult1.next()) {
                                                        if (newUserId.getText().equals(myResult1.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as customer! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                while (myResult2.next()) {
                                                        if (newUserId.getText().equals(myResult2.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as dev! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                if (valid) {
                                                        psstm.setInt(1, Integer.parseInt(newUserId.getText()));
                                                        psstm.setString(2, newUserName.getText());
                                                        psstm.setString(3, null);
                                                        psstm.executeUpdate();
                                                        cardLayout4use.show(cardLayout, "7");
                                                        JOptionPane.showMessageDialog(null, "Success!!");
                                                }

                                                newUserName.setText("");
                                                newUserId.setText("");
                                                psstm.close();
                                                conn.close();
                                        }
                                        catch(Exception ex){
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                }
                        }
                });
                backendLogout.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "1"); }
                });
                backToAdminActionsDev.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "7"); }
                });
                devComplete.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                if (newDevId.getText().equals("")) {
                                        JOptionPane.showMessageDialog(null, "Please enter an DEVID");
                                }
                                else{
                                        String mainDatabase = "MAIN_DATABASE";
                                        String connectionURL = "jdbc:derby:" + mainDatabase + ";create=true";
                                        Connection conn = null;
                                        ResultSet myResult1 = null, myResult2 = null;

                                        try {
                                                conn = DriverManager.getConnection(connectionURL);
                                                PreparedStatement psstm = conn.prepareStatement("INSERT into DEV (DEVID, OWNEDGAMES) VALUES (?,?)");
                                                Statement stm = conn.createStatement();
                                                Statement stm2 = conn.createStatement();
                                                String query = "SELECT DEVID FROM DEV";
                                                String query2 = "SELECT ID FROM CUST";
                                                myResult1 = stm.executeQuery(query);
                                                myResult2 = stm2.executeQuery(query2);
                                                boolean valid = true;
                                                while (myResult1.next()) {
                                                        if (newDevId.getText().equals(myResult1.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as dev! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                while (myResult2.next()){
                                                        if (newDevId.getText().equals(myResult2.getString(1))) {
                                                                JOptionPane.showMessageDialog(null, "ID already exists as customer! Please select another");
                                                                valid = false;
                                                        }
                                                }
                                                if (valid) {
                                                        psstm.setInt(1, Integer.parseInt(newDevId.getText()));
                                                        psstm.setString(2,"");
                                                        psstm.executeUpdate();
                                                        cardLayout4use.show(cardLayout, "7");
                                                        JOptionPane.showMessageDialog(null, "Success!!");
                                                }

                                                newDevId.setText("");
                                                psstm.close();
                                                myResult1.close();
                                                conn.close();
                                        }
                                        catch(Exception ex){
                                                System.out.println("ERROR!");
                                                ex.printStackTrace();
                                        }
                                }
                        }
                });
                addDev.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) { cardLayout4use.show(cardLayout, "12"); }
                });

        }


        @Override
        public void actionPerformed(ActionEvent e) {

        }
}

